from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import lru_cache

import pandas as pd

from itlm_db_connector.base import Database
from itlm_db_connector.connection_pool import ConnectionPool
from itlm_db_connector.utils.custom_exception import (
    DatabaseConnectionError,
    QueryExecutionError,
    QueryInsufficientPrivilegesError
)


class PostgreSQL(Database):
    dialect = "postgresql"

    def __init__(self, host, username, password, database, no_of_sample_rows=None, **kwargs):
        """
        Initialize the PostgreSQL database connector object.
        :param host: The hostname of the PostgreSQL database.
        :param username: The username to connect to the PostgreSQL database.
        :param password: The password to connect to the PostgreSQL database.
        :param database: The name of the PostgreSQL database.
        :param schema: The schema to use in the PostgreSQL database. Default is 'public'.
        :param port: The port to connect to the PostgreSQL database. Default is 5432.
        :param no_of_sample_rows: The number of sample rows to fetch from the table. Default is 5.
        :param kwargs: Additional keyword arguments.
        :type host: str
        :type username: str
        :type password: str
        :type database: str
        :type schema: str
        :type port: int
        :type no_of_sample_rows: int
        :type kwargs: dict
        :raises DatabaseConnectionError: If there is an error connecting to the PostgreSQL database.
        :return: None
        :rtype: None
        """
        try:
            import psycopg2
        except ImportError:
            raise ImportError("Please install the 'psycopg2' package to use the PostgreSQL connector.")
        self.host = host
        self.username = username
        self.password = password
        self.database = database
        self.schema = kwargs.get("schema", "public")
        self.port = kwargs.get("port", 5432)

        self.no_of_sample_rows = no_of_sample_rows if no_of_sample_rows else 5

    def create_connection(self):
        """
        Establish and return a connection to the Snowflake database.
        If used outside a context manager, ensure to close the cursors and connection after use.
        :returns: PostgreSQL connection object.
        """
        try:
            import psycopg2
        except ImportError:
            raise ImportError("Please install the 'psycopg2' package to use the PostgreSQL connector.")

        try:
            connection = psycopg2.connect(
                host=self.host,
                user=self.username,
                password=self.password,
                database=self.database,
                port=self.port,
                options=f'-c search_path={self.schema}'
            )
            cursor = connection.cursor()
            cursor.execute("SELECT version();")
            db_version = cursor.fetchone()

            if not db_version[0]:
                cursor.close()
                connection.close()
                raise DatabaseConnectionError("Error connecting to PostgreSQL.")
            cursor.close()
        except Exception as e:
            raise DatabaseConnectionError(f"Error connecting to PostgreSQL: {str(e)}")
        return connection

    @lru_cache(maxsize=3)
    def fetch_table_from_db(self):
        """
        Fetch all available tables from the Snowflake database.

        :returns:
            `list[dict[str, list[str]]`:
                A list of dictionaries where each dictionary represents a table.
                Each dictionary contains:
                    - name (str): The name of the table.
                    - columns (list[str]): A list of column names in the table.
        """
        try:
            import psycopg2
        except ImportError:
            raise ImportError("Please install the 'psycopg2' package to use the PostgreSQL connector.")

        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                cursor.execute("""
                                SELECT table_name, column_name
                                FROM information_schema.columns
                                WHERE table_schema = %s
                                ORDER BY table_name, UPPER(column_name) ASC
                            """, (self.schema,))

                table_columns = defaultdict(list)
                for table, column in cursor:
                    table_columns[table].append(column)

                return [{"name": table, "columns": columns} for table, columns in table_columns.items()]

            except Exception as e:
                return Exception(f"Error fetching tables from the database: {e}")
            finally:
                cursor.close()
                pool.return_connection(connection)

    @lru_cache(maxsize=3)
    def search_table(self, table_name: str, cursor=None):
        """
        Search for a table in the Snowflake database and return the table information for similar matches.
        :returns:
            `list[dict[str, list[str]]`:
                A list of dictionaries where each dictionary represents a table.
                Each dictionary contains:
                    - name (str): The name of the table.
                    - columns (list[str]): A list of column names in the table.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                query = """
                        SELECT table_name, column_name
                        FROM information_schema.columns
                        WHERE table_schema = %s
                        AND table_name ILIKE %s
                        ORDER BY table_name, UPPER(column_name) ASC
                        """
                cursor.execute(query, (self.schema, f"%{table_name}%"))
                rows = cursor.fetchall()
                table_columns = defaultdict(list)

                for table, column in rows:
                    table_columns[table].append(column)

                return [{"name": table, "columns": columns} for table, columns in table_columns.items()]
            except Exception as e:
                return Exception(f"Error searching tables from the database: {e}")
            finally:
                cursor.close()
                pool.return_connection(connection)

    def get_ddl(self, table_name: str, cursor=None):
        """
        Get the DDL (Data Definition Language) for a table in the PostgreSQL database.
        :param table_name: The name of the table.
        :param cursor: [Advanced usecase only] The cursor object to use for fetching the DDL. Default is None.
        :returns: `str` -> The DDL for the table.
        """
        if cursor:
            return self._fetch_ddl(table_name, cursor)
        else:
            return self._fetch_ddl_cached(table_name)

    def _fetch_ddl(self, table_name, cursor):
        """
        Fetch the DDL for a table in the PostgreSQL database using the passed cursor.
        Implementation for uncached response.
        """
        try:
            query = f"""
                                SELECT 'CREATE TABLE ' || table_name || ' (' ||
                                    string_agg(column_name || ' ' || data_type ||
                                    CASE
                                        WHEN character_maximum_length IS NOT NULL
                                        THEN '(' || character_maximum_length || ')'
                                        ELSE '' END ||
                                    CASE WHEN is_nullable = 'NO' THEN ' NOT NULL' ELSE '' END, ', ') ||
                                ');'
                                FROM information_schema.columns
                                WHERE table_name = '{table_name}'
                                GROUP BY table_name;
                                """
            cursor.execute(query)
            result = cursor.fetchone()
            if not result:
                raise Exception(f"table '{table_name}' not found in the database.")
            ddl = result[0]
            return str(ddl)
        except Exception as e:
            raise Exception(f"Error getting DDL for {table_name}: {str(e)}")

    @lru_cache(maxsize=10)
    def _fetch_ddl_cached(self, table_name: str):
        """
        Fetch the DDL for a table in PostgreSQL with caching using the connection pool.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                query = f"""
                    SELECT 'CREATE TABLE ' || table_name || ' (' ||
                        string_agg(column_name || ' ' || data_type ||
                        CASE
                            WHEN character_maximum_length IS NOT NULL
                            THEN '(' || character_maximum_length || ')'
                            ELSE '' END ||
                        CASE WHEN is_nullable = 'NO' THEN ' NOT NULL' ELSE '' END, ', ') ||
                    ');'
                    FROM information_schema.columns
                    WHERE table_name = '{table_name}'
                    GROUP BY table_name;
                    """
                cursor.execute(query)
                result = cursor.fetchone()
                if not result:
                    raise Exception(f"table '{table_name}' not found in the database.")
                ddl = result[0]
                return str(ddl)
            except Exception as e:
                raise Exception(f"Error getting DDL for {table_name}: {str(e)}")
            finally:
                if cursor:
                    cursor.close()
                pool.return_connection(connection)

    def get_table_info(self, table_names: list[str] = None, max_connections=10):
        """
        Get the table information (DDL + Sample rows) for all/specified tables in the Snowflake database.
        :param table_names: List of table names to get information (DDL + Sample rows) for. Default=None is all tables.
        :param max_connections: Maximum number of connections to be used.
                                Default is 10. |
                                0 means no limit (can be dangerous).
        :returns: `str` -> The formatted table information (DDL + Sample rows).
        """
        if table_names is None:
            table_names = []
        if not table_names:
            tables = self.fetch_table_from_db()
            table_names = [item["name"] for item in tables]
        table_info = []

        if max_connections == 0:
            max_connections = len(table_names)
        else:
            max_connections = min(max_connections, len(table_names))

        def fetch_table_data(table_name, connection_pool):
            """
            Fetch the DDL and sample rows query for a given table by getting connection from given pool.
            """
            connection = connection_pool.get_connection()
            ddl_cursor = None
            sample_row_cursor = None
            try:
                ddl_cursor = connection.cursor()
                sample_row_cursor = connection.cursor()
                with ThreadPoolExecutor(max_workers=2) as query_executor:
                    ddl_future = query_executor.submit(self.get_ddl, table_name, ddl_cursor)
                    rows_future = query_executor.submit(self._get_sample_rows_query_using_cursor,
                                                        table_name, sample_row_cursor)
                    # Wait for both tasks to complete
                    table_ddl = ddl_future.result()
                    sample_rows = rows_future.result()
                    return "\n" + table_ddl + "\n" + sample_rows + "\n"

            except Exception as e:
                raise e
            finally:
                if ddl_cursor is not None:
                    ddl_cursor.close()
                if sample_row_cursor is not None:
                    sample_row_cursor.close()
                connection_pool.return_connection(connection)

        with ConnectionPool(self, max_connections) as pool:
            with ThreadPoolExecutor(max_workers=max_connections) as executor:
                futures = []
                for table in table_names:
                    futures.append(executor.submit(fetch_table_data, table, pool))

                # Wait for all tasks to complete
                for future in as_completed(futures):
                    try:
                        result = future.result()
                        table_info.append(result)
                    except Exception as err:
                        raise Exception(f"Error fetching table info: {err}")
        return " ".join(table_info)

    def get_sample_rows_query(self, table_name: str):
        """
        Get the sample rows query for a table in the Snowflake database.
        :param table_name: The name of the table.
        :returns: `str` -> The formatted sample rows query.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                formatted_data = self._get_sample_rows_query_using_cursor(table_name, cursor)
                return str(formatted_data)
            except Exception as e:
                raise Exception(f"Error getting sample rows: {e}")
            finally:
                if cursor is not None:
                    cursor.close()
                pool.return_connection(connection)

    def _get_sample_rows_query_using_cursor(self, table_name, cursor):
        """
        For internal use only: Get the sample rows query for a table in the Snowflake database using passed cursor.
        """
        sample_rows_extraction_query = f"SELECT * FROM {table_name} LIMIT " + str(self.no_of_sample_rows)
        cursor.execute(sample_rows_extraction_query)
        column_names = [desc[0] for desc in cursor.description]
        results = cursor.fetchall()
        formatted_results = [f"\nSample table rows for the table: {table_name}", '\t'.join(column_names)]
        for row in results:
            formatted_row = '\t'.join([str(value) if value is not None else 'None' for value in row])
            formatted_results.append(formatted_row)
        formatted_data = '\n'.join(formatted_results)
        return str(formatted_data)

    def execute_query(self, query: str):
        """
        Execute the SQL query on the PostgreSQL database.
        :param query: The SQL query to execute.
        :returns: `pandas.DataFrame` -> The result of the query.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                cursor.execute(query)
                rows = cursor.fetchall()
                columns = [desc[0] for desc in cursor.description]
                return pd.DataFrame(rows, columns=columns)

            except Exception as e:
                if hasattr(e, 'pgcode') and e.pgcode == '42501':
                    raise QueryInsufficientPrivilegesError(
                        f"Insufficient privileges to execute the query: {str(e)}"
                    )
                raise QueryExecutionError(f"Error executing query: {str(e)}")
            finally:
                if cursor:
                    cursor.close()
                pool.return_connection(connection)
