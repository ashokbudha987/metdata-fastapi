from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import lru_cache

import pandas as pd

from itlm_db_connector.base import Database
from itlm_db_connector.connection_pool import ConnectionPool
from itlm_db_connector.utils.custom_exception import (
    DatabaseConnectionError,
    QueryExecutionError, QueryInsufficientPrivilegesError
)


class Oracle(Database):
    dialect = "oracle"

    def __init__(self, host, username, password, database, no_of_sample_rows = None,**kwargs):
        """
        Initialize the Oracle database connection.
        |
        Required Parameters:
            - host: The hostname or IP address of the Oracle database server.
            - username: The Oracle database username/schema to connect to.
            - password: The password for the Oracle database username.
            - database: The Oracle database service name.
            - port: The port number of the Oracle database server.
            Note: DSN = host:port/database , database = service_name
        |
        Optional Parameters:
            - no_of_sample_rows: The number of sample rows to fetch from the table.
        """
        try:
            import oracledb
        except ImportError as e:
            raise ImportError(
                "The 'oracledb' module is required to be installed to use the Oracle database connector."
            ) from e
        self.host = host
        self.username = username
        self.password = password
        self.service_name = database
        self.port = kwargs.get("port") if kwargs.get("port") else 1521

        self.dsn = f"{host}:{self.port}/{self.service_name}"

        self.no_of_sample_rows = no_of_sample_rows if no_of_sample_rows else 5

    def create_connection(self):
        """
        Establish and return a connection to the Oracle database.
        If used outside a context manager, ensure to close the cursors and connection after use.
        :returns: Oracledb connection object.
        """
        try:
            import oracledb
        except ImportError as e:
            raise ImportError(
                "The 'oracledb' module is required to be installed to use the Oracle database connector."
            ) from e

        try:
            connection = oracledb.connect(
                user=self.username,
                password=self.password,
                dsn=self.dsn
            )
            with connection.cursor() as cursor:
                cursor.execute("SELECT 1 FROM DUAL")
                result = cursor.fetchone()
                if result is None or result[0] != 1:
                    raise DatabaseConnectionError(
                        "Test query failed. Could not establish a proper connection to the Oracle database."
                    )
        except oracledb.DatabaseError as db_err:
            raise DatabaseConnectionError(f"Oracle Database error: {str(db_err)}") from db_err
        except Exception as e:
            raise DatabaseConnectionError(f"Unexpected error connecting to Oracle Database: {str(e)}") from e
        return connection

    @lru_cache(maxsize=3)
    def fetch_table_from_db(self):
        """
        Fetch all available tables from the Snowflake database.

        :returns:
            `list[dict[str, list[str]]`:
                A list of dictionaries where each dictionary represents a table.
                Each dictionary contains:
                    - name (str): The name of the table.
                    - columns (list[str]): A list of column names in the table.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()

                cursor.execute(
                    """
                    SELECT t.table_name, c.column_name
                    FROM user_tables t
                    LEFT JOIN user_tab_columns c
                    ON t.table_name = c.table_name
                    ORDER BY UPPER(t.table_name), UPPER(c.column_name)
                    """
                )

                table_columns = defaultdict(list)
                for table_name, column_name in cursor.fetchall():
                    if column_name:  # Avoid None for tables with no columns
                        table_columns[table_name].append(column_name)

                return [
                    {"name": table, "columns": table_columns[table]}
                    for table in sorted(table_columns.keys())
                ]
            except Exception as e:
                raise Exception(f"Error fetching tables from the database: {e}")
            finally:
                if cursor is not None:
                    cursor.close()
                pool.return_connection(connection)

    @lru_cache(maxsize=3)
    def search_table(self, table_name: str, cursor=None):
        """
        Search for a table in the Snowflake database and return the table information for similar matches.
        :returns:
            `list[dict[str, list[str]]`:
                A list of dictionaries where each dictionary represents a table.
                Each dictionary contains:
                    - name (str): The name of the table.
                    - columns (list[str]): A list of column names in the table.
        """
        if not table_name:
            raise ValueError("Table name is required.")

        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()

                query = """SELECT table_name from user_tables
                    WHERE UPPER(table_name) LIKE UPPER(:searchParam) ESCAPE '\\'
                    ORDER BY UPPER(table_name) ASC"""

                escaped_tablename = table_name.replace("_", "\\_")
                cursor.execute(query, searchParam=f"%{escaped_tablename}%")

                tables = [item[0] for item in cursor]
                table_columns = defaultdict(list)

                for table in tables:
                    cursor.execute(
                        """SELECT column_name FROM user_tab_columns
                        WHERE table_name= :table_name
                        ORDER BY UPPER(column_name) ASC""",
                        {"table_name": table},
                    )
                    columns = [column[0] for column in cursor.fetchall()]
                    table_columns[table] = columns

                return [
                    {"name": table, "columns": columns}
                    for table, columns in table_columns.items()
                ]
            except Exception as e:
                raise Exception(f"Error searching tables from the database: {e}")
            finally:
                if cursor is not None:
                    cursor.close()
                pool.return_connection(connection)

    def get_ddl(self, table_name: str, cursor=None):
        """
        Get the DDL (Data Definition Language) for a table in the Oracle database.
        :param table_name: The name of the table.
        :param cursor: [Advanced usecase only] The cursor object to use for fetching the DDL. Default is None.
        :returns: `str` -> The DDL for the table.
        """
        if cursor is not None:
            return self._fetch_ddl(table_name, cursor)
        else:
            return self._fetch_ddl_cached(table_name)

    def _fetch_ddl(self, table_name, cursor):
        """
        Fetch the DDL for a table in the Snowflake database using the passed cursor.
        Implementation for uncached response.
        """
        try:
            query = f"SELECT DBMS_METADATA.GET_DDL('TABLE', '{table_name}', '{self.username}') AS DDL FROM DUAL"
            result = cursor.execute(query).fetchone()
            if not result:
                raise Exception(f"Table {table_name} not found in the database.")
            ddl = result[0]
            return str(ddl)
        except Exception as e:
            raise Exception(f"Error getting DDLs: {str(e)}")

    @lru_cache(maxsize=10)
    def _fetch_ddl_cached(self, table_name: str):
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()

                query = f"SELECT DBMS_METADATA.GET_DDL('TABLE', '{table_name}', '{self.username}') AS DDL FROM DUAL"
                cursor.execute(query)
                ddl = cursor.fetchone()
                if not ddl:
                    raise Exception(f"Table {table_name} not found in the database.")
                return str(ddl[0])
            except Exception as e:
                raise Exception(f"Error getting DDLs: {str(e)}")
            finally:
                if cursor is not None:
                    cursor.close()
                pool.return_connection(connection)

    #
    def execute_query(self, query:str):
        """
        Execute a SQL query on the Oracle database.
        :param query: The SQL query to execute.
        :returns: `pandas.DataFrame` -> The result of the query.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                cursor.execute(query)
                rows = cursor.fetchall()
                columns = [desc[0] for desc in cursor.description]
                return pd.DataFrame(rows, columns=columns)

            except oracledb.DatabaseError as e:
                error, = e.args
                if hasattr(error, 'code') and error.code == 1031:
                    raise QueryInsufficientPrivilegesError(
                        f"Insufficient privileges to execute the query: {str(e)}"
                    )
                else:
                    raise QueryExecutionError(
                        f"Error executing query, Code: {error.code if hasattr(error, 'code') else 'unknown'}: {str(e)}")
            except Exception as e:
                raise QueryExecutionError(f"Error executing query: {str(e)}")

            finally:
                if cursor is not None:
                    cursor.close()
                pool.return_connection(connection)

    def get_sample_rows_query(self, table_name: str):
        """
        Get the sample rows query for a table in the Oracle database.
        :param table_name: The name of the table.
        :returns: `str` -> The formatted sample rows query.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                formatted_data = self._get_sample_rows_query_using_cursor(table_name, cursor)
                return str(formatted_data)
            except Exception as e:
                raise Exception(f"Error getting sample rows: {e}")
            finally:
                if cursor is not None:
                    cursor.close()
                pool.return_connection(connection)

    def _get_sample_rows_query_using_cursor(self, table_name, cursor):
        """
        For internal use only: Get the sample rows query for a table in the Snowflake database using passed cursor.
        """
        sample_rows_extraction_query = f"SELECT * FROM {table_name} FETCH FIRST {str(self.no_of_sample_rows)} ROWS ONLY"
        cursor.execute(sample_rows_extraction_query)
        column_names = [desc[0] for desc in cursor.description]
        results = cursor.fetchall()
        formatted_results = [f"\nSample table rows for the table: {table_name}", '\t'.join(column_names)]
        for row in results:
            formatted_row = '\t'.join([str(value) if value is not None else 'None' for value in row])
            formatted_results.append(formatted_row)
        formatted_data = '\n'.join(formatted_results)
        return str(formatted_data)

    def get_table_info(self, table_names:list[str]=None, max_connections=10):
        """
        Get the table information (DDL + Sample rows) for all/specified tables in the Snowflake database.
        :param table_names: List of table names to get information (DDL + Sample rows) for. Default=None is all tables.
        :param max_connections: Maximum number of connections to be used.
                                Default is 10. |
                                0 means no limit (can be dangerous).
        :returns: `str` -> The formatted table information (DDL + Sample rows).
        """
        if table_names is None:
            table_names = []
        if not table_names:
            tables = self.fetch_table_from_db()
            table_names = [item["name"] for item in tables]
        table_info = []

        if max_connections == 0:
            max_connections = len(table_names)
        else:
            max_connections = min(max_connections, len(table_names))

        def fetch_table_data(table_name, connection_pool):
            """
            Fetch the DDL and sample rows query for a given table by getting connection from given pool.
            """
            connection = connection_pool.get_connection()
            ddl_cursor = None
            sample_row_cursor = None
            try:
                ddl_cursor = connection.cursor()
                sample_row_cursor = connection.cursor()
                with ThreadPoolExecutor(max_workers=2) as query_executor:
                    ddl_future = query_executor.submit(self.get_ddl, table_name, ddl_cursor)
                    rows_future = query_executor.submit(self._get_sample_rows_query_using_cursor,
                                                        table_name, sample_row_cursor)
                    # Wait for both tasks to complete
                    table_ddl = ddl_future.result()
                    sample_rows = rows_future.result()
                    return "\n" + table_ddl + "\n" + sample_rows + "\n"

            except Exception as err:
                raise Exception(f"Error fetching table data: {err}")
            finally:
                if ddl_cursor is not None:
                    ddl_cursor.close()
                if sample_row_cursor is not None:
                    sample_row_cursor.close()
                connection_pool.return_connection(connection)  # Return connection to the pool

        with ConnectionPool(self, max_connections) as pool:
            with ThreadPoolExecutor(max_workers=max_connections) as executor:
                futures = []
                for table in table_names:
                    futures.append(executor.submit(fetch_table_data, table, pool))

                # Wait for all tasks to complete
                for future in as_completed(futures):
                    try:
                        result = future.result()
                        table_info.append(result)
                    except Exception as e:
                        raise Exception(f"Error fetching table data: {e}")

        return " ".join(table_info)
