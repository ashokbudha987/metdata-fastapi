from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import lru_cache

import pandas as pd

from itlm_db_connector.base import Database
from itlm_db_connector.connection_pool import ConnectionPool
from itlm_db_connector.utils.custom_exception import (
    DatabaseConnectionError,
    QueryInsufficientPrivilegesError,
    QueryExecutionError
)


class Mssql(Database):
    dialect = "mssql"

    def __init__(self, host, username, password, database, no_of_sample_rows = None,**kwargs):
        """
        Initialize the Mssql database connection.
        |
        Required parameters:
            - host: The Mssql host/server.
            - username: The Mssql username (user).
            - password: The Mssql password.
            - database: The Mssql database.
        |
        Optional parameters to be passed in **kwargs:
            - schema: The Mssql schema to use by default.
        |
        Other Optional Params:
            - no_of_sample_rows: The number of sample rows to fetch. Default is 5.

        """
        try:
            import pymssql
        except ImportError:
            raise ImportError("Please install 'pymssql' package to use the Mssql connector.")
        self.server = host
        self.database = database
        self.user = username
        self.password = password

        self.schema = kwargs.get('schema', None)
        self.port = kwargs.get("port", 1433)
        self.no_of_sample_rows = no_of_sample_rows if no_of_sample_rows else 5

    def create_connection(self):
        """
        Establish and return a connection to the Mssql database.
        If used outside a context manager, ensure to close the cursors and connection after use.
        :returns: MSSql connection object.
        """
        try:
            import pymssql
        except ImportError:
            raise ImportError("Please install 'pymssql' package to use the Mssql connector.")
        try:
            connection = pymssql.connect(
                user=self.user,
                password=self.password,
                server=self.server,
                database=self.database,
                port=self.port
            )
            with connection.cursor() as cursor:
                cursor.execute("SELECT @@VERSION AS 'SQL Server Version';")
                conn_params = cursor.fetchone()
                if not conn_params:
                    if connection:
                        connection.close()
                    raise DatabaseConnectionError(
                        "Could not connect to Mssql. Please check your connection parameters.")
        except  DatabaseConnectionError as e:
            raise e
        except Exception as e:
            raise DatabaseConnectionError(f"Error connecting to Mssql: {str(e)}")
        return connection

    @lru_cache(maxsize=3)
    def fetch_table_from_db(self):
        """
        Fetch all available tables from the Snowflake database.

        :returns:
            `list[dict[str, list[str]]`:
                A list of dictionaries where each dictionary represents a table.
                Each dictionary contains:
                    - name (str): The name of the table.
                    - columns (list[str]): A list of column names in the table.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                query = """
                                    SELECT 
                                        TABLE_NAME, COLUMN_NAME
                                    FROM 
                                        INFORMATION_SCHEMA.COLUMNS
                                    WHERE 
                                        TABLE_CATALOG = %s {schema_condition}
                                    ORDER BY 
                                        TABLE_NAME, COLUMN_NAME
                                """

                schema_condition = f"AND TABLE_SCHEMA = %s" if self.schema else ""
                cursor.execute(query.format(schema_condition=schema_condition),
                               (self.database, self.schema) if self.schema else (self.database,))

                meta = defaultdict(list)
                for row in cursor.fetchall():
                    meta[row[0]].append(row[1])

                return [
                    {"name": table, "columns": sorted(columns, key=lambda col: col.lower())}
                    for table, columns in meta.items()
                ]
            except Exception:
                raise Exception("Could not fetch table information from Mssql.")
            finally:
                if cursor is not None:  # Close cursor only if it was created
                    cursor.close()
                pool.return_connection(connection)

    @lru_cache(maxsize=3)
    def search_table(self, table_name: str, cursor=None):
        """
        Search for a table in the Snowflake database and return the table information for similar matches.
        :returns:
            `list[dict[str, list[str]]`:
                A list of dictionaries where each dictionary represents a table.
                Each dictionary contains:
                    - name (str): The name of the table.
                    - columns (list[str]): A list of column names in the table.
        """
        if not table_name:
            raise ValueError("Table name is required.")

        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                # Construct the query with the correct parameterized placeholders for MSSQL
                query = """
                    SELECT TABLE_NAME, COLUMN_NAME 
                    FROM INFORMATION_SCHEMA.COLUMNS 
                    WHERE TABLE_CATALOG = %s {schema_condition} 
                    AND TABLE_NAME LIKE %s
                    ORDER BY TABLE_NAME, COLUMN_NAME
                """
                # Include schema condition if schema is provided
                schema_condition = "AND TABLE_SCHEMA = %s" if self.schema else ""

                # If schema is provided, pass schema; otherwise, skip it
                if self.schema:
                    cursor.execute(query.format(schema_condition=schema_condition),
                                   (self.database, self.schema, f"%{table_name}%"))
                else:
                    cursor.execute(query.format(schema_condition=schema_condition),
                                   (self.database, f"%{table_name}%"))

                # Collect metadata
                meta = defaultdict(list)
                for row in cursor.fetchall():
                    meta[row[0]].append(row[1])

                # Return the results with columns sorted alphabetically
                return [
                    {"name": table, "columns": sorted(columns, key=lambda col: col.lower())}
                    for table, columns in meta.items()
                ]
            except Exception:
                raise Exception("Could not fetch table information from Mssql.")
            finally:
                if cursor:  # Simplified check for cursor
                    cursor.close()
                pool.return_connection(connection)

    def get_ddl(self, table_name: str, cursor=None):
        """
        Get the DDL (Data Definition Language) for a table in the MS SQL database.
        :param table_name: The name of the table.
        :param cursor: [Advanced usecase only] The cursor object to use for fetching the DDL. Default is None.
        :returns: `str` -> The DDL for the table.
        """
        if cursor:
            return self._fetch_ddl(table_name, cursor)
        else:
            return self._fetch_ddl_cached(table_name)

    def _fetch_ddl(self, table_name, cursor):
        """
        Fetch the DDL for a table in the MS SQL database using the passed cursor.
        Implementation for uncached response.
        """
        try:
            # Get table schema
            schema_condition = "TABLE_SCHEMA = %s AND " if self.schema else ""

            table_query = f"""
            SELECT 
                COLUMN_NAME,
                DATA_TYPE,
                CHARACTER_MAXIMUM_LENGTH,
                NUMERIC_PRECISION,
                NUMERIC_SCALE,
                IS_NULLABLE,
                COLUMN_DEFAULT
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE {schema_condition} TABLE_NAME = %s
            ORDER BY ORDINAL_POSITION
            """

            # If schema is provided, pass schema; otherwise, skip it
            if self.schema:
                cursor.execute(table_query, (self.schema, table_name))
            else:
                cursor.execute(table_query, (table_name))

            columns = cursor.fetchall()

            if not columns:
                table_identifier = f"{self.schema}.{table_name}" if self.schema else table_name
                raise Exception(f"Table {table_identifier} not found in the database.")

            column_defs = []
            for col in columns:
                name, data_type, char_max_len, num_precision, num_scale, is_nullable, default = col

                # Build column definition
                col_def = [name]

                # Handle data type
                if data_type in ('char', 'varchar', 'nchar', 'nvarchar'):
                    if char_max_len == -1:
                        col_def.append(f"{data_type}(max)")
                    else:
                        col_def.append(f"{data_type}({char_max_len})")
                elif data_type in ('decimal', 'numeric'):
                    col_def.append(f"{data_type}({num_precision},{num_scale})")
                else:
                    col_def.append(data_type)

                # Nullability
                col_def.append("NULL" if is_nullable == 'YES' else "NOT NULL")

                # Default value
                if default:
                    col_def.append(f"DEFAULT {default}")

                column_defs.append(" ".join(col_def))

            # Get primary key constraints
            schema_condition = " AND kcu.TABLE_SCHEMA = %s " if self.schema else ""

            pk_query = f"""
                SELECT kcu.COLUMN_NAME
                FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE kcu
                INNER JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc 
                ON kcu.CONSTRAINT_NAME = tc.CONSTRAINT_NAME
                WHERE tc.CONSTRAINT_TYPE = 'PRIMARY KEY'
                AND kcu.TABLE_NAME = %s {schema_condition}
                ORDER BY kcu.ORDINAL_POSITION
                """
            if self.schema:
                cursor.execute(pk_query, (table_name, self.schema))
            else:
                cursor.execute(pk_query, (table_name))
            pk_columns = [row[0] for row in cursor.fetchall()]

            # Build CREATE TABLE statement
            table_identifier = f"{self.schema}.{table_name}" if self.schema else table_name
            ddl = [f"CREATE TABLE {table_identifier} ("]

            # Add primary key constraint if exists
            if pk_columns:
                schema_prefix = f"{self.schema}_" if self.schema else ""
                pk_constraint = f"CONSTRAINT PK_{schema_prefix}{table_name} PRIMARY KEY ({', '.join(pk_columns)})"
                column_defs.append(pk_constraint)

            ddl.append(",\n    ".join(column_defs))
            ddl.append(")")

            return "\n".join(ddl)

        except Exception as e:
            table_identifier = f"{self.schema}.{table_name}" if self.schema else table_name
            raise Exception(f"Error getting DDLs for {table_identifier}: {str(e)}")

    @lru_cache(maxsize=10)
    def _fetch_ddl_cached(self, table_name: str):
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                return self._fetch_ddl(table_name, cursor)
            except Exception as e:
                raise Exception(f"Error getting DDLs: {str(e)}")
            finally:
                if cursor is not None:
                    cursor.close()
                pool.return_connection(connection)

    def execute_query(self, query:str):
        """
        Execute a SQL query on the MS SQL database.
        :param query: The SQL query to execute.
        :returns: `pandas.DataFrame` -> The result of the query.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                cursor.execute(query)
                rows = cursor.fetchall()
                columns = [desc[0] for desc in cursor.description] if cursor.description else []
                return pd.DataFrame(rows, columns=columns)

            except Exception as e:
                # MS SQL Server error codes for permission-related issues
                permission_error_codes = [
                    229,  # The SELECT permission was denied
                    230,  # The INSERT permission was denied
                    231,  # The UPDATE permission was denied
                    232,  # The DELETE permission was denied
                    262,  # CREATE TABLE permission denied
                    297,  # The user does not have permission to perform this action
                    15151,  # Cannot execute as the database principal
                    15247,  # User does not have permission to perform this action
                    15622  # Login failed
                ]

                # Check for MS SQL specific error code in the exception
                if hasattr(e, 'args') and len(e.args) > 0:
                    error_msg = str(e.args[0])
                    # MS SQL errors typically start with "[SQL Server]" followed by the error number
                    if '[SQL Server]' in error_msg:
                        try:
                            # Extract error number - typically in format "[SQL Server Msg XXXX, Level XX, State X, Line XX]"
                            error_parts = error_msg.split(',')[0]
                            digits = ''.join(filter(str.isdigit, error_parts))
                            if digits:  # Ensure digits were found
                                error_code = int(digits)
                                if error_code in permission_error_codes:
                                    raise QueryInsufficientPrivilegesError(
                                        f"Insufficient privileges to execute the query: {str(e)}"
                                    )
                            else:
                                raise ValueError("Couldn't determine error code.")
                        except ValueError:
                            # If we can't parse the error code, fall through to generic error
                            pass

                raise QueryExecutionError(f"Error executing query: {str(e)}")
            finally:
                if cursor is not None:  # Close cursor only if it was created
                    cursor.close()
                pool.return_connection(connection)

    def get_table_info(self, table_names:list[str]=None, max_connections=10):
        """
        Get the table information (DDL + Sample rows) for all/specified tables in the Snowflake database.
        :param table_names: List of table names to get information (DDL + Sample rows) for. Default=None is all tables.
        :param max_connections: Maximum number of connections to be used.
                                Default is 10. |
                                0 means no limit (can be dangerous).
        :returns: `str` -> The formatted table information (DDL + Sample rows).
        """
        if table_names is None:
            table_names = []
        if not table_names:
            tables = self.fetch_table_from_db()
            table_names = [item["name"] for item in tables]
        table_info = []

        if max_connections == 0:
            max_connections = len(table_names)
        else:
            max_connections = min(max_connections, len(table_names))

        def fetch_table_data(table_name, connection_pool):
            """
            Fetch the DDL and sample rows query for a given table by getting connection from given pool.
            """
            connection = connection_pool.get_connection()
            cursor = None
            try:
                cursor = connection.cursor()
                table_ddl = self.get_ddl(table_name, cursor)
                sample_rows = self._get_sample_rows_query_using_cursor(table_name, cursor)
                return "\n" + table_ddl + "\n" + sample_rows + "\n"

            except Exception as e:
                raise Exception(f"Error fetching table data: {e}")
            finally:
                if cursor is not None:
                    cursor.close()
                connection_pool.return_connection(connection)

        with ConnectionPool(self, max_connections) as pool:
            with ThreadPoolExecutor(max_workers=max_connections) as executor:
                futures = []
                for table in table_names:
                    futures.append(executor.submit(fetch_table_data, table, pool))

                # Wait for all tasks to complete
                for future in as_completed(futures):
                    try:
                        result = future.result()
                        table_info.append(result)
                    except Exception as err:
                        raise Exception(f"Error fetching table data: {err}")
        return " ".join(table_info)

    def get_sample_rows_query(self, table_name: str):
        """
        Get the sample rows query for a table in the MS SQL database.
        :param table_name: The name of the table.
        :returns: `str` -> The formatted sample rows query.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                formatted_data = self._get_sample_rows_query_using_cursor(table_name, cursor)
                return str(formatted_data)
            except Exception as e:
                table_identifier = f"{self.schema}.{table_name}" if self.schema else table_name
                raise Exception(f"Error getting sample rows from {table_identifier}: {e}")
            finally:
                if cursor is not None:
                    cursor.close()
                pool.return_connection(connection)

    def _get_sample_rows_query_using_cursor(self, table_name, cursor):
        """
        For internal use only: Get the sample rows query for a table in the Mssql database using passed cursor.
        """
        table_identifier = f"{self.schema}.{table_name}" if self.schema else table_name

        # MS SQL Server syntax for TOP N rows
        sample_rows_extraction_query = f"SELECT TOP {self.no_of_sample_rows} * FROM {table_identifier}"

        cursor.execute(sample_rows_extraction_query)
        column_names = [desc[0] for desc in cursor.description]
        results = cursor.fetchall()
        table_header = f"\nSample table rows for the table: {table_identifier}"
        column_header = '\t'.join(column_names)
        formatted_results = [table_header, column_header]
        for row in results:
            formatted_row = '\t'.join([
                'NULL' if value is None
                else str(value).replace('\n', '\\n').replace('\t', '\\t')
                for value in row
            ])
            formatted_results.append(formatted_row)
        formatted_data = '\n'.join(formatted_results)
        return str(formatted_data)
