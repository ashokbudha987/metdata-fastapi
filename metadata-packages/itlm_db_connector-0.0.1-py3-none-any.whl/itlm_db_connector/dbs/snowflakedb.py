from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import lru_cache

import pandas as pd

from itlm_db_connector.base import Database
from itlm_db_connector.connection_pool import ConnectionPool
from itlm_db_connector.utils.custom_exception import (
    DatabaseConnectionError,
    QueryInsufficientPrivilegesError,
    QueryExecutionError
)


class Snowflake(Database):
    dialect = "snowflake"

    def __init__(self, host, username, password, database, no_of_sample_rows = None,**kwargs):
        """
        Initialize the Snowflake database connection.
        |
        Required parameters:
            :param host: The Snowflake account (host).
            :param username: The Snowflake username (user).
            :param password: The Snowflake password.
            :param database: The Snowflake database.
            :param warehouse: The Snowflake warehouse.
            :param schema: The Snowflake schema.

        Optional parameters to be passed in **kwargs:
            - role: The Snowflake role.
        |
        Other Optional Params:
            - no_of_sample_rows: The number of sample rows to fetch. Default is 5.

        """
        try:
            import snowflake.connector as snowflake_connector
        except ImportError:
            raise ImportError("Please install the 'snowflake-connector-python' package to use this connector.")
        self.username = username
        self.password = password
        self.account = host
        self.database = database
        self.warehouse = kwargs.get('warehouse')
        self.schema = kwargs.get('schema')
        self.role = kwargs.get("role")

        self.no_of_sample_rows = no_of_sample_rows if no_of_sample_rows else 5

    def create_connection(self):
        """
        Establish and return a connection to the Snowflake database.
        If used outside a context manager, ensure to close the cursors and connection after use.
        :returns: Snowflake connection object.
        """
        try:
            import snowflake.connector as snowflake_connector
        except ImportError:
            raise ImportError("Please install the 'snowflake-connector-python' package to use this connector.")
        try:
            connection = snowflake_connector.connect(
                user=self.username,
                password=self.password,
                account=self.account,
                database=self.database,
                schema=self.schema,
                warehouse=self.warehouse,
                role=self.role,
                # network_timeout=21600,  # 6hours of inactivity or stall.
            )
        except Exception as e:
            raise DatabaseConnectionError(f"Error connecting to Snowflake: {str(e)}")
        conn_params = (
            connection.cursor().execute("SELECT CURRENT_WAREHOUSE(), CURRENT_DATABASE(), CURRENT_SCHEMA()")).fetchone()
        if not all(conn_params):
            connection.close()
            raise DatabaseConnectionError("Could not connect to Snowflake. Please check your connection parameters.")
        return connection

    @lru_cache(maxsize=3)
    def fetch_table_from_db(self):
        """
        Fetch all available tables from the Snowflake database.

        :returns:
            `list[dict[str, list[str]]`:
                A list of dictionaries where each dictionary represents a table.
                Each dictionary contains:
                    - name (str): The name of the table.
                    - columns (list[str]): A list of column names in the table.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                response = cursor.execute(
                    "SHOW COLUMNS IN SCHEMA IDENTIFIER(%s)",
                    (f"{self.database}.{self.schema}",),
                )
                meta = defaultdict(list)
                for row in response:
                    meta[row[0]].append(row[2])
                return [
                    {"name": table, "columns": sorted(columns, key=lambda col: str.upper(col))}
                    for table, columns in meta.items()
                ]
            except Exception:
                raise Exception("Could not fetch table information from Snowflake.")
            finally:
                if cursor is not None:  # Close cursor only if it was created
                    cursor.close()
                pool.return_connection(connection)

    @lru_cache(maxsize=3)
    def search_table(self, table_name: str, cursor=None):
        """
        Search for a table in the Snowflake database and return the table information for similar matches.
        :returns:
            `list[dict[str, list[str]]`:
                A list of dictionaries where each dictionary represents a table.
                Each dictionary contains:
                    - name (str): The name of the table.
                    - columns (list[str]): A list of column names in the table.
        """
        if not table_name:
            raise ValueError("Table name is required.")

        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                response = cursor.execute(
                    "SHOW COLUMNS IN SCHEMA IDENTIFIER(%s)",
                    (f"{self.database}.{self.schema}",),
                )
                meta = defaultdict(list)
                for row in response:
                    if table_name.lower() in row[0].lower():
                        meta[row[0]].append(row[2])
                return [
                    {"name": table, "columns": sorted(columns, key=lambda col: str.upper(col))}
                    for table, columns in meta.items()
                ]
            except Exception:
                raise Exception("Could not fetch table information from Snowflake.")
            finally:
                if cursor is not None:  # Close cursor only if it was created
                    cursor.close()
                pool.return_connection(connection)

    def get_ddl(self, table_name: str, cursor=None):
        """
        Get the DDL (Data Definition Language) for a table in the Snowflake database.
        :param table_name: The name of the table.
        :param cursor: [Advanced usecase only] The cursor object to use for fetching the DDL. Default is None.
        :returns: `str` -> The DDL for the table.
        """
        if cursor:
            return self._fetch_ddl(table_name, cursor)
        else:
            return self._fetch_ddl_cached(table_name)

    def _fetch_ddl(self, table_name, cursor):
        """
        Fetch the DDL for a table in the Snowflake database using the passed cursor.
        Implementation for uncached response.
        """
        try:
            query = f"SELECT GET_DDL('table', '{self.schema}.{table_name}')"
            cursor.execute(query)
            result = cursor.fetchone()
            if not result:
                raise Exception(f"Table {table_name} not found in the database.")
            ddl = result[0]
            return str(ddl)
        except Exception as e:
            raise Exception(f"Error getting DDLs: {str(e)}")

    @lru_cache(maxsize=10)
    def _fetch_ddl_cached(self, table_name: str):
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                query = f"SELECT GET_DDL('table', '{self.schema}.{table_name}')"
                cursor.execute(query)
                result = cursor.fetchone()
                if not result:
                    raise Exception(f"Table {table_name} not found in the database.")
                ddl = result[0]
                return str(ddl)
            except Exception as e:
                raise Exception(f"Error getting DDLs: {str(e)}")
            finally:
                if cursor is not None:
                    cursor.close()
                pool.return_connection(connection)

    def execute_query(self, query:str):
        """
        Execute a SQL query on the Snowflake database.
        :param query: The SQL query to execute.
        :returns: `pandas.DataFrame` -> The result of the query.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                cursor.execute(query)
                rows = cursor.fetchall()
                columns = [desc[0] for desc in cursor.description]
                return pd.DataFrame(rows, columns=columns)

            except Exception as e:
                if hasattr(e, 'orig') and e.orig is not None:
                    orig_code = str(e.orig).split()[0]
                    if orig_code == "003001":
                        raise QueryInsufficientPrivilegesError(
                            f"Insufficient privileges to execute the query: {str(e)}"
                        )
                raise QueryExecutionError(f"Error executing query: {str(e)}")
            finally:
                if cursor is not None:  # Close cursor only if it was created
                    cursor.close()
                pool.return_connection(connection)

    def get_table_info(self, table_names:list[str]=None, max_connections=10):
        """
        Get the table information (DDL + Sample rows) for all/specified tables in the Snowflake database.
        :param table_names: List of table names to get information (DDL + Sample rows) for. Default=None is all tables.
        :param max_connections: Maximum number of connections to be used.
                                Default is 10. |
                                0 means no limit (can be dangerous).
        :returns: `str` -> The formatted table information (DDL + Sample rows).
        """
        if table_names is None:
            table_names = []

        if not table_names:
            tables = self.fetch_table_from_db()
            table_names = [item["name"] for item in tables]
        table_info = []

        if max_connections == 0:
            max_connections = len(table_names)
        else:
            max_connections = min(max_connections, len(table_names))

        def fetch_table_data(table_name, connection_pool):
            """
            Fetch the DDL and sample rows query for a given table by getting connection from given pool.
            """
            connection = connection_pool.get_connection()
            ddl_cursor = None
            sample_row_cursor = None
            try:
                ddl_cursor = connection.cursor()
                sample_row_cursor = connection.cursor()
                with ThreadPoolExecutor(max_workers=2) as query_executor:
                    ddl_future = query_executor.submit(self.get_ddl, table_name, ddl_cursor)
                    rows_future = query_executor.submit(self._get_sample_rows_query_using_cursor,
                                                        table_name, sample_row_cursor)
                    # Wait for both tasks to complete
                    table_ddl = ddl_future.result()
                    sample_rows = rows_future.result()
                    return "\n" + table_ddl + "\n" + sample_rows + "\n"

            except Exception as e:
                raise Exception(f"Error fetching table data: {e}")
            finally:
                if ddl_cursor is not None:
                    ddl_cursor.close()
                if sample_row_cursor is not None:
                    sample_row_cursor.close()
                connection_pool.return_connection(connection)

        with ConnectionPool(self, max_connections) as pool:
            with ThreadPoolExecutor(max_workers=max_connections) as executor:
                futures = []
                for table in table_names:
                    futures.append(executor.submit(fetch_table_data, table, pool))

                # Wait for all tasks to complete
                for future in as_completed(futures):
                    try:
                        result = future.result()
                        table_info.append(result)
                    except Exception as err:
                        raise Exception(f"Error fetching table data: {err}")
        return " ".join(table_info)

    def get_sample_rows_query(self, table_name: str):
        """
        Get the sample rows query for a table in the Snowflake database.
        :param table_name: The name of the table.
        :returns: `str` -> The formatted sample rows query.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                formatted_data = self._get_sample_rows_query_using_cursor(table_name, cursor)
                return str(formatted_data)
            except Exception as e:
                table_identifier = f"{self.schema}.{table_name}" if self.schema else table_name
                raise Exception(f"Error getting sample rows from {table_identifier}: {e}")
            finally:
                if cursor is not None:
                    cursor.close()
                pool.return_connection(connection)

    def _get_sample_rows_query_using_cursor(self, table_name, cursor):
        """
        For internal use only: Get the sample rows query for a table in the Snowflake database using passed cursor.
        """
        # Construct table identifier with schema if provided
        table_identifier = f"{self.schema}.{table_name}" if self.schema is not None else table_name

        sample_rows_extraction_query = f"SELECT * FROM {table_identifier} LIMIT " + str(self.no_of_sample_rows)
        cursor.execute(sample_rows_extraction_query)
        column_names = [desc[0] for desc in cursor.description]
        results = cursor.fetchall()
        formatted_results = [f"\nSample table rows for the table: {table_identifier}", '\t'.join(column_names)]
        for row in results:
            formatted_row = '\t'.join([str(value) if value is not None else 'None' for value in row])
            formatted_results.append(formatted_row)
        formatted_data = '\n'.join(formatted_results)
        return str(formatted_data)
