from collections import defaultdict
from itlm_db_connector.base import Database
from itlm_db_connector.utils.custom_exception import (
    DatabaseConnectionError,
    QueryExecutionError
)
import pandas as pd

class MySQL(Database):
    dialect = "mysql"
    try:
        import mysql.connector
    except ImportError:
        raise ImportError("Please install the 'mysql-connector-python' package")

    def __init__(self, host, username, password, database, no_of_sample_rows = None,**kwargs):
        self.host = host
        self.username = username
        self.password = password
        self.database = database
        self.schema = kwargs.get("schema")
        self.included_tables = kwargs.get("included_tables")
        self.port = kwargs.get("port")
        self.no_of_sample_rows = no_of_sample_rows if no_of_sample_rows else 5
    
    def create_connection(self):
        """Establish a connection to the MySQL database."""
        try:
            import mysql.connector
        except ImportError:
            raise ImportError("Please install the 'mysql-connector-python' package")
        try:
            connection = mysql.connector.create_connection(
                host=self.host,
                user=self.username,
                password=self.password,
                database=self.database,
                port=self.port,
            )
            return connection
        except Exception as e:
            raise DatabaseConnectionError(f"Error connecting to MySQL: {str(e)}")

    def fetch_table_from_db(self):
        """
        Fetch all available tables from the Snowflake database.

        :returns:
            `list[dict[str, list[str]]`:
                A list of dictionaries where each dictionary represents a table.
                Each dictionary contains:
                    - name (str): The name of the table.
                    - columns (list[str]): A list of column names in the table.
        """

        conn = self.create_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(
                """SELECT table_name FROM information_schema.tables
                WHERE table_schema NOT IN ('information_schema', 'performance_schema')
                ORDER BY UPPER(table_name) ASC"""
            )

            tables = [table[0] for table in cursor]

            table_columns = defaultdict(list)
            for table in tables:
                cursor.execute(
                    """SELECT column_name FROM information_schema.columns
                    WHERE table_name = %s ORDER BY UPPER(column_name) ASC""",
                    (table,),
                )
                columns = [column[0] for column in cursor]
                table_columns[table] = columns

            return [
                {"name": table, "columns": columns}
                for table, columns in table_columns.items()
            ]
        except Exception as e:
            return Exception(f"Error fetching tables from the database: {e}")
        finally:
            cursor.close()
            conn.close()

    def get_ddl(self, table_name: str, cursor=None):
        conn = self.create_connection()
        if conn is None:
            return None

        cursor = conn.cursor()
        try:
            query = """SELECT table_name FROM information_schema.tables
            WHERE table_schema NOT IN ('information_schema', 'performance_schema')
            AND UPPER(table_name) LIKE UPPER(%s)
            ORDER BY UPPER(table_name) ASC"""

            escaped_tablename = table_name.replace("_", "\\_")
            cursor.execute(query, (f"%{escaped_tablename}%",))

            tables = [table[0] for table in cursor]
            table_columns = defaultdict(list)

            for table in tables:
                cursor.execute(
                    """SELECT column_name FROM information_schema.columns
                    WHERE table_name = %s ORDER BY UPPER(column_name) ASC""",
                    (table,),
                )
                columns = [column[0] for column in cursor]
                table_columns[table] = columns

            return [
                {"name": table, "columns": columns}
                for table, columns in table_columns.items()
            ]

        except Exception as e:
            return Exception(f"Error searching tables from the database: {e}")
        finally:
            cursor.close()
            conn.close()
    
    def get_ddl(self, table):
        """
        Get the DDL (Data Definition Language) for a table in the MySQL database.
        """
        try:
            connection = self.create_connection()
            cursor = connection.cursor()
            query = f"SHOW CREATE TABLE {table};"
            cursor.execute(query)
            ddl = cursor.fetchone()[1]
            return str(ddl)
        except Exception as e:
            raise Exception(f"Error getting DDLs: {str(e)}")
        finally:
            cursor.close()
            connection.close()
    
    def get_sample_rows_query(self, table_name: str):
        """
        Get the sample rows query for a table in the MySQL database.
        """
        try:
            sample_rows_extraction_query = f"SELECT * FROM {table_name} LIMIT "+str(self.no_of_sample_rows)
            connection = self.create_connection()
            cursor = connection.cursor()
            cursor.execute(sample_rows_extraction_query)
            column_names = [desc[0] for desc in cursor.description]
            results = cursor.fetchall()
            formatted_results = []
            formatted_results.append(f"\nSample table rows for the table: {table_name}")
            formatted_results.append('\t'.join(column_names))
            for row in results:
                formatted_row = '\t'.join([str(value) if value is not None else 'None' for value in row])
                formatted_results.append(formatted_row)
            formatted_data = '\n'.join(formatted_results)
            return str(formatted_data)
        except Exception as e:
            raise Exception(f"Error getting sample rows: {e}")
        finally: 
            connection.close()
            cursor.close()

    def execute_query(self, query:str):
        """
        Execute the SQL query on the MySQL database.
        """
        try: 
            connection = self.create_connection()
            cursor = connection.cursor()
            cursor.execute(query)
            rows = cursor.fetchall()
            columns = [desc[0] for desc in cursor.description]
            return pd.DataFrame(rows, columns=columns)
        except Exception as e:
            raise QueryExecutionError(f"Error executing query: {str(e)}")
        finally:
            cursor.close()
            connection.close()

    def _get_table_names(self):
        """
        Fetch all table names from the MySQL database.
        """
        if not self.included_tables:
            tables = self.fetch_table_from_db()
            table_names = [item["name"] for item in tables]
            return table_names
        return self.included_tables
    
    def get_table_info(self, table_names=None):
        table_names = self._get_table_names()
        table_info = []
        ddl= ""
        for table in table_names:
            ddl += self.get_ddl(table)
            ddl += "\n" + self.get_sample_rows_query(table)
            table_info.append(ddl)
        return " ".join(table_info)
    
