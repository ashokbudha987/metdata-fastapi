import os
import sqlite3
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import lru_cache

import pandas as pd

from itlm_db_connector.base import Database
from itlm_db_connector.connection_pool import ConnectionPool
from itlm_db_connector.utils.custom_exception import (
    DatabaseConnectionError,
    QueryExecutionError
)


class Sqlite(Database):
    dialect = "sqlite"

    def __init__(self, host=None, username=None, password=None, database=None, no_of_sample_rows = None,**kwargs):
        """
        Initialize the Sqlite database connection.
        |
        Required parameters:
            - database: The name/path of the database to connect to.
        Other Optional Params:
            - no_of_sample_rows: The number of sample rows to fetch. Default is 5.

        """
        self.database = database

        self.no_of_sample_rows = no_of_sample_rows if no_of_sample_rows else 5

    def create_connection(self):
        """
        Establish and return a connection to the Sqlite database.
        If used outside a context manager, ensure to close the cursors and connection after use.
        :returns: SQLite connection object.
        """
        try:
            if self.database != ":memory:" and (not os.path.exists(self.database)):
                raise DatabaseConnectionError(f"Database file '{self.database}' does not exist.")
            connection = sqlite3.connect(self.database, check_same_thread=False)
            conn_test = (connection.cursor().execute("SELECT sqlite_version();")).fetchone()[0]
            if not all(conn_test):
                raise DatabaseConnectionError("Could not connect to Sqlite. Please check your connection parameters.")
        except Exception as e:
            raise DatabaseConnectionError(f"Error connecting to Sqlite: {str(e)}")

        return connection

    @lru_cache(maxsize=3)
    def fetch_table_from_db(self):
        """
        Fetch all available tables from the Snowflake database.

        :returns:
            `list[dict[str, list[str]]`:
                A list of dictionaries where each dictionary represents a table.
                Each dictionary contains:
                    - name (str): The name of the table.
                    - columns (list[str]): A list of column names in the table.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()

                cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
                tables = [table[0] for table in cursor.fetchall()]

                meta = defaultdict(list)
                for table_name in tables:
                    cursor.execute(f"PRAGMA table_info({table_name});")
                    columns = cursor.fetchall()
                    for column in columns:
                        meta[table_name].append(column[1])

                return [
                    {"name": table, "columns": sorted(columns, key=lambda col: str.upper(col))}
                    for table, columns in meta.items()
                ]
            except Exception:
                raise Exception("Could not fetch table information from Sqlite.")
            finally:
                if cursor is not None:  # Close cursor only if it was created
                    cursor.close()
                pool.return_connection(connection)

    @lru_cache(maxsize=3)
    def search_table(self, table_name: str, cursor=None):
        """
        Search for a table in the Snowflake database and return the table information for similar matches.
        :returns:
            `list[dict[str, list[str]]`:
                A list of dictionaries where each dictionary represents a table.
                Each dictionary contains:
                    - name (str): The name of the table.
                    - columns (list[str]): A list of column names in the table.
        """
        if not table_name:
            raise ValueError("Table name is required.")

        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()

                cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
                tables = cursor.fetchall()
                meta = defaultdict(list)

                for table in tables:
                    table_name_in_db = table[0]
                    if table_name.lower() in table_name_in_db.lower():  # Case-insensitive search
                        cursor.execute(f"PRAGMA table_info({table_name_in_db});")
                        columns = cursor.fetchall()
                        for column in columns:
                            meta[table_name_in_db].append(column[1])  # column[1] is the column name

                return [
                    {"name": table, "columns": sorted(columns, key=lambda col: str.upper(col))}
                    for table, columns in meta.items()
                ]
            except Exception as e:
                raise Exception(f"Could not fetch table information from Sqlite: {str(e)}")
            finally:
                if cursor is not None:
                    cursor.close()
                pool.return_connection(connection)

    def get_ddl(self, table_name: str, cursor=None):
        """
        Get the DDL (Data Definition Language) for a table in the Sqlite database.
        :param table_name: The name of the table.
        :param cursor: [Advanced usecase only] The cursor object to use for fetching the DDL. Default is None.
        :returns: `str` -> The DDL for the table.
        """
        if cursor:
            return self._fetch_ddl(table_name, cursor)
        else:
            return self._fetch_ddl_cached(table_name)

    def _fetch_ddl(self, table_name, cursor):
        """
        Fetch the DDL for a table in the Sqlite database using the passed cursor.
        Implementation for uncached response.
        """
        try:
            query = f"SELECT sql FROM sqlite_master WHERE type='table' AND name=?"
            result = cursor.execute(query, (table_name,)).fetchone()
            if not result:
                raise Exception(f"Table {table_name} not found in the database.")
            ddl = result[0]
            return str(ddl)
        except Exception as e:
            raise Exception(f"Error getting DDL: {str(e)}")

    @lru_cache(maxsize=10)
    def _fetch_ddl_cached(self, table_name: str):
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()

                query = f"SELECT sql FROM sqlite_master WHERE type='table' AND name=?"
                result = cursor.execute(query, (table_name,)).fetchone()
                if not result:
                    raise Exception(f"Table {table_name} not found in the database.")
                ddl = result[0]
                return str(ddl)
            except Exception as e:
                raise Exception(f"Error getting DDL: {str(e)}")
            finally:
                if cursor is not None:
                    cursor.close()
                pool.return_connection(connection)

    def execute_query(self, query:str):
        """
        Execute a SQL query on the Sqlite database.
        :param query: The SQL query to execute.
        :returns: `pandas.DataFrame` -> The result of the query.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()

                cursor.execute(query)
                rows = cursor.fetchall()
                columns = [desc[0] for desc in cursor.description]

                return pd.DataFrame(rows, columns=columns)

            except sqlite3.DatabaseError as e:
                raise QueryExecutionError(f"Error executing query: {str(e)}")

            finally:
                if cursor is not None:  # Close cursor only if it was created
                    cursor.close()
                pool.return_connection(connection)

    def get_table_info(self, table_names:list[str]=None, max_connections=10):
        """
        Get the table information (DDL + Sample rows) for all/specified tables in the Snowflake database.
        :param table_names: List of table names to get information (DDL + Sample rows) for. Default=None is all tables.
        :param max_connections: Maximum number of connections to be used.
                                Default is 10. |
                                0 means no limit (can be dangerous).
        :returns: `str` -> The formatted table information (DDL + Sample rows).
        """
        if table_names is None:
            table_names = []
        if not table_names:
            tables = self.fetch_table_from_db()
            table_names = [item["name"] for item in tables]
        table_info = []

        if max_connections == 0:
            max_connections = len(table_names)
        else:
            max_connections = min(max_connections, len(table_names))

        def fetch_table_data(table_name, connection_pool):
            """
            Fetch the DDL and sample rows query for a given table by getting connection from given pool.
            """
            connection = connection_pool.get_connection()
            ddl_cursor = None
            sample_row_cursor = None
            try:
                ddl_cursor = connection.cursor()
                sample_row_cursor = connection.cursor()
                with ThreadPoolExecutor(max_workers=2) as query_executor:
                    ddl_future = query_executor.submit(self.get_ddl, table_name, ddl_cursor)
                    rows_future = query_executor.submit(self._get_sample_rows_query_using_cursor,
                                                        table_name, sample_row_cursor)
                    # Wait for both tasks to complete
                    table_ddl = ddl_future.result()
                    sample_rows = rows_future.result()
                    return "\n" + table_ddl + "\n" + sample_rows + "\n"

            except Exception as e:
                raise Exception(f"Error fetching table data: {e}")
            finally:
                if ddl_cursor is not None:
                    ddl_cursor.close()
                if sample_row_cursor is not None:
                    sample_row_cursor.close()
                connection_pool.return_connection(connection)  # Return connection to the pool

        with ConnectionPool(self, max_connections) as pool:
            with ThreadPoolExecutor(max_workers=max_connections) as executor:
                futures = []
                for table in table_names:
                    futures.append(executor.submit(fetch_table_data, table, pool))

                # Wait for all tasks to complete
                for future in as_completed(futures):
                    try:
                        result = future.result()
                        table_info.append(result)
                    except Exception as err:
                        raise Exception(f"Error fetching table data: {err}")

        return " ".join(table_info)

    def get_sample_rows_query(self, table_name: str):
        """
        Get the sample rows query for a table in the Sqlite database.
        :param table_name: The name of the table.
        :returns: `str` -> The formatted sample rows query.
        """
        with ConnectionPool(self, 1) as pool:
            connection = pool.get_connection()
            try:
                cursor = connection.cursor()
                formatted_data = self._get_sample_rows_query_using_cursor(table_name, cursor)
                return str(formatted_data)
            except Exception as e:
                raise Exception(f"Error getting sample rows: {e}")
            finally:
                if cursor is not None:
                    cursor.close()
                pool.return_connection(connection)

    def _get_sample_rows_query_using_cursor(self, table_name, cursor):
        """
       For internal use only: Get the sample rows query for a table in the SQLite database using the passed cursor.

       Args:
           table_name (str): The name of the table to fetch sample rows from.
           cursor (sqlite3.Cursor): The SQLite cursor to execute the query.

       Returns:
           str: A formatted string containing the table name, column names, and sample rows.
       """
        sample_rows_extraction_query = f"SELECT * FROM {table_name} LIMIT {self.no_of_sample_rows}"
        cursor.execute(sample_rows_extraction_query)
        column_names = [desc[0] for desc in cursor.description]
        results = cursor.fetchall()
        formatted_results = [f"\nSample table rows for the table: {table_name}", '\t'.join(column_names)]
        for row in results:
            formatted_row = '\t'.join([str(value) if value is not None else 'None' for value in row])
            formatted_results.append(formatted_row)
        formatted_data = '\n'.join(formatted_results)
        return str(formatted_data)
