from abc import ABC, abstractmethod


class Database(ABC):
    dialect = None

    @abstractmethod
    def create_connection(self):
        pass

    @abstractmethod
    def execute_query(self, query:str):
        pass

    @abstractmethod
    def get_ddl(self, table_name: str, cursor=None):
        pass

    @abstractmethod
    def search_table(self, table_name: str, cursor=None):
        pass

    @abstractmethod
    def fetch_table_from_db(self):
        pass

    @abstractmethod
    def get_table_info(self):
        pass
