class DatabaseConnectionError(Exception):
    def __init__(self, message="Error Connecting to the Database"):
        """
        Initializes a DatabaseConnectionError exception with a custom error message.

        Args:
            message (str): The custom error message. Defaults to "Error Connecting to the Database".

        Returns:
            None
        """
        self.message = message
        super().__init__(self.message)


class QueryExecutionError(Exception):
    def __init__(self, message="Error Executing SQL Query"):
        """
        Initializes the class with a custom error message.

        Args:
            message (str, optional): The error message to display. Defaults to "Error Executing SQL Query".

        Returns:
            None
        """
        self.message = message
        super().__init__(self.message)


class QueryInsufficientPrivilegesError(Exception):
    def __init__(self, message="Insufficient Privileges to Execute the Query"):
        """
        Initializes the class with a custom error message.

        Args:
            message (str): The error message to display. Defaults to "Insufficient Privileges to Execute the Query".

        Returns:
            None
        """
        self.message = message
        super().__init__(self.message)

class PossibleDanglingConnectionError(Exception):
    def __init__(self, message="Some connections forcibly closed. Not All connections returned to the Pool. Don't leave dangling connection or close connections manually"):
        """
        Initializes the class with a custom error message.

        Args:
            message (str): The error message to display. Defaults to "Not All connections returned to the Pool. Don't leave dangling connection or close connections manually".

        Returns:
            None
        """
        self.message = message
        super().__init__(self.message)