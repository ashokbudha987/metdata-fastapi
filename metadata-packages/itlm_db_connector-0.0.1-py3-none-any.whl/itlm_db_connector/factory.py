# from .dbs.mssql import Mssql
# # from dbs.mysql import MySQL
# from .dbs.oracle import Oracle
# from .dbs.postgresql import PostgreSQL
# from .dbs.snowflakedb import Snowflake
# from .dbs.sqlite import Sqlite
#
#
# class DatabaseFactory:
#     @staticmethod
#     def get_connector(db_type):
#         connector_classes = {
#             "SNOWFLAKE": Snowflake,
#             "ORACLE": Oracle,
#             "POSTGRESQL": PostgreSQL,
#             # "MYSQL": MySQL,
#             "SQLITE": Sqlite,
#             "MSSQL": Mssql
#         }
#         if db_type in connector_classes:
#             return connector_classes[db_type]
#         else:
#             raise ValueError(f"Unsupported database type: {db_type}")
import pkgutil
import importlib
import inspect
from pathlib import Path


class DatabaseFactory:
    @staticmethod
    def _load_connectors():
        package_name = "itlm_db_connector.dbs"  # Adjust if necessary
        package_path = Path(__file__).parent / "dbs"

        connector_classes = {}
        for module_info in pkgutil.iter_modules([str(package_path)]):
            module_name = f"{package_name}.{module_info.name}"
            module = importlib.import_module(module_name)
            for attr_name, attr_value in inspect.getmembers(module, inspect.isclass):
                if attr_value.__module__ == module_name:  # Ensure class is defined in this module
                    connector_classes[attr_name.upper()] = attr_value

        return connector_classes

    @staticmethod
    def get_connector(db_type):
        connector_classes = DatabaseFactory._load_connectors()
        if db_type in connector_classes:
            return connector_classes[db_type]
        else:
            raise ValueError(f"Unsupported database type: {db_type}")
