from collections import deque
from concurrent.futures import ThreadPoolExecutor
from queue import Queue

from .utils.custom_exception import PossibleDanglingConnectionError


class ConnectionPool:
    def __init__(self, db_object, max_size=4):
        """
        Initialize the ConnectionPool for the passed database connection object.
        :param db_object: Database connector object instance to be used to connect to DB for the pool.
        :param max_size: Maximum number of connections to be created.
        """
        self.max_size = max_size
        self.db_object = db_object
        self.pool = Queue(maxsize=self.max_size)
        self.busy_pool = deque()

    def __enter__(self):
        """
        Enter the context manager.
        :returns: ConnectionPool object instance.
        """
        self._initialize_pool()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Exit the context manager.
        Closes all connections. If an exception is raised, it will close all connections and raise the exception.
        Raises PossibleDanglingConnectionError if not all connections are returned to the pool when exiting context manager.
        """
        if exc_type is not None:
            raise Exception(f"{exc_val}, {exc_tb}.\nClosing all connections!")
        self.close_all_connections()

    def _initialize_pool(self):
        """
        Initialize a connection pool for a specific database type and connection parameters.
        """

        def create_connection(_):
            connection_instance = self.db_object.create_connection()
            return connection_instance

        with ThreadPoolExecutor(max_workers=self.max_size) as executor:
            connections = list(executor.map(create_connection, range(self.max_size)))

        for connection in connections:
            self.pool.put(connection)

    def get_connection(self):
        """
        Retrieve a connection from the pool.
        :returns: Connection object instance.
        """
        connection = self.pool.get()
        self.busy_pool.append(connection)
        return connection

    def return_connection(self, connection):
        """
        Return a connection back to the pool.
        """
        self.pool.put(connection)
        self.busy_pool.remove(connection)
        return

    def close_all_connections(self):
        """
        Closes all connections in all pools.
        Raises PossibleDanglingConnectionError if not all connections are returned to the pool when called.
        """
        err = False
        if len(self.busy_pool) > 0:
            err = True

        def close_connection(connection_instance):
            connection_instance.close()

        with ThreadPoolExecutor() as executor:
            while not self.pool.empty():
                connection = self.pool.get()
                executor.submit(close_connection, connection)
            while not len(self.busy_pool) == 0:
                connection = self.busy_pool.pop()
                executor.submit(close_connection, connection)

        if err:
            raise PossibleDanglingConnectionError()
        return
