import os

from generators.prompt.BasePrompt import BasePrompt


class MetadataGeneratorPrompt(BasePrompt):
    current_dir = os.path.dirname(os.path.abspath(__file__))
    _prompt_url = os.path.join(
        current_dir,
        "assets",
        "generate_metadata_prompt.tmpl",
    )

    def __init__(self, vars):
        self.vars = vars

    def get(self):
        try:
            with open(self._prompt_url, "r") as file:
                prompt = file.read()
            prompt = self.set_var(prompt, self.vars)
            return prompt
        except Exception as e:
            raise RuntimeError(f"Error getting prompt: {e}")
