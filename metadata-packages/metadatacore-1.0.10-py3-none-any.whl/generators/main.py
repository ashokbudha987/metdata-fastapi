import yaml
from simple_ddl_parser import DDLParser

from generators.connectors.snowflake import Snowflake
from generators.llm_metadata_generator import LLMMetadataGenerator
from generators.pythonic_metadata_generator import PythonicMetadataGenerator

snow = Snowflake()


def read_config(yaml_file):
    """
    Reads a YAML file and generates a dictionary of subject areas
    and their tables.

    Args:
        yaml_file (str): Path to the YAML file.

    Returns:
        dict: Dictionary where keys are subject areas and
        values are lists of tables.
    """
    with open(yaml_file, "r") as file:
        configs = yaml.safe_load(file)
    return configs


def extract_ddl_for_subject_areas(subject_area, tables):
    """
    Extracts the DDL (Data Definition Language)
    for the given subject area and tables.

    Args:
        subject_area (str): The subject area for which to extract the DDL.
        tables (list): A list of table names for which to extract the DDL.

    Returns:
        list: A list of DDL strings for the specified tables.
    """
    ddls = [""]
    for table in tables:
        ddl = snow.get_ddl(
            table
        )  # Assuming get_ddl takes a table name and returns the DDL for it
        if ddl:
            ddls.append(ddl)
    return ddls


def main(parsed_ddl, method="manual", ddl=""):
    if method == "manual":
        pyGenerate = PythonicMetadataGenerator()
        return pyGenerate.generate(parsed_ddl)
    elif method == "llm":
        llmGenerate = LLMMetadataGenerator()
        return llmGenerate.generate(parsed_ddl, ddl)
    else:
        exit(0)


if __name__ == "__main__":
    file = "config.yml"
    config = read_config(file)
    for subject_area, tables in config.items():
        ddls = extract_ddl_for_subject_areas(subject_area, tables)

        if not ddls:
            continue

        results = []

        for ddl in ddls:
            parsed_ddl = DDLParser(ddl).run(output_mode="hql")

            if not parsed_ddl:
                continue

            result = main(parsed_ddl[0], "llm", ddl)
            results.append(result)

        if results:
            # Convert list of OrderedDicts to YAML
            yaml_data = yaml.dump(results, sort_keys=False)

            # Write the YAML to a file named after the subject area
            file_name = f"{subject_area}.yml"
            with open(file_name, "w") as file:
                file.write(yaml_data)
        else:
            print("Failed to generate metadata for subject area: {subject_area}")
