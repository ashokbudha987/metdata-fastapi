import re
from typing import Any, Dict

import yaml
from decouple import config
from langchain_openai import ChatOpenAI  
from langchain.chains.llm import LLMChain
from langchain_core.prompts.prompt import PromptTemplate

from generators.generator import MetadataGenerator
from generators.prompt.MetadataGeneratorPrompt import MetadataGeneratorPrompt


class LLMMetadataGenerator(MetadataGenerator):
    OPENAI_API_KEY = config("API_KEY")
    model = config("MODEL")
    prompt_template = "generate_metadata_prompt.tmpl"

    def __init__(self):
        super().__init__()
        self.llm = ChatOpenAI(
            api_key=self.OPENAI_API_KEY,
            model_name=self.model,
        )

    def generate(self, parsed_ddl: Dict[str, Any], ddl) -> Dict[str, Any]:
        """
        Function to parse DDL and generate metadata
        """
        prompt = PromptTemplate(
            template=MetadataGeneratorPrompt({"parsed_ddl": ddl}).get()
        )

        chain = LLMChain(llm=self.llm, prompt=prompt)

        # Run the chain with the provided DDL
        response = chain.run(
            {
                "ddl": yaml.dump(
                    parsed_ddl,
                    default_flow_style=False,
                )
            }
        )

        # Extract YAML string using regex
        yaml_match = re.search(r"```yaml\s*([\s\S]*?)\s*```", response)
        if yaml_match:
            yaml_str = yaml_match.group(1)
            try:
                metadata = yaml.safe_load(yaml_str)
            except yaml.YAMLError as e:
                return {}
        else:
            return {}

        self.final_metadata["subject_area"] = metadata.get("subject_area")
        self.final_metadata["source"] = metadata.get("source")
        self.final_metadata["attributes"] = metadata.get("attributes")
        self.final_metadata["metrics"] = metadata.get("metrics")

        return self.final_metadata

    def get_prompt(self):
        try:
            with open(self._prompt_url, "r") as file:
                prompt = file.read()
            prompt = self.set_var(prompt, self.vars)
            return prompt
        except Exception as e:
            raise RuntimeError(f"Error getting prompt: {e}")
