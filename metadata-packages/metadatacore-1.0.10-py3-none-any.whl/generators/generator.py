class MetadataGenerator:
    """
    Interface for metadata generator
    """

    def __init__(self):
        self._name = "Metadata Generator"
        self.final_metadata = {
            "subject_area": "",
            "source": [{"table": "", "joins": []}],
            "attributes": {},
            "metrics": {},
        }

    def generate(self, parsed_ddl: dict):
        pass
