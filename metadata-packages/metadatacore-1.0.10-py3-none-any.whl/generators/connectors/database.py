from abc import ABC


class Database(ABC):
    def __init__(self, name, host, port, user, password):
        self.hostname = None
        self.username = None
        self.password = None

    def __str__(self):
        return self.name

    def get_ddl(self):
        pass
