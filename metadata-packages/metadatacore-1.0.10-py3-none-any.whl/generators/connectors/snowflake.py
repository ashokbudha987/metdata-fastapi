import snowflake
from connectors.database import Database
from decouple import config


class Snowflake(Database):
    def __init__(self):
        self.account = config("SNOWFLAKE_HOST")
        self.username = config("SNOWFLAKE_USERNAME")
        self.password = config("SNOWFLAKE_PASSWORD")
        self.database = config("SNOWFLAKE_DATABASE")
        self.schema = config("SNOWFLAKE_SCHEMA")
        self.warehouse = config("SNOWFLAKE_WAREHOUSE")
        self.role = config("SNOWFLAKE_ROLE")

    def create_connection(self):
        conn = snowflake.connector.connect(
            user=self.username,
            password=self.password,
            account=self.account,
            warehouse=self.warehouse,
            database=self.database,
            schema=self.schema,
        )
        return conn

    def __str__(self):
        return self.name

    def get_ddl(self, table_name):
        with self.create_connection() as conn:
            cur = conn.cursor()
            query = f"SELECT GET_DDL('table', '{table_name.upper()}')"
            cur.execute(query)
            ddl = cur.fetchone()[0]

            return ddl
