from generators.generator import MetadataGenerator


class PythonicMetadataGenerator(MetadataGenerator):
    """
    Metadata generator based on LLM
    """

    def __init__(self):
        super().__init__()

    def generate(self, parsed_ddl: dict) -> str:
        try:
            table_name = parsed_ddl.get("table_name")
            if not table_name:
                raise ValueError("Table name does not exist in parsed DDL.")
        except ValueError as e:
            raise e

        # Adding the main table to the source
        main_table_entry = {
            "table": f"{parsed_ddl.get('table_name')}",
            "joins": [],  # Joins can be added here if available
        }
        self.final_metadata["source"].append(main_table_entry)
        self.final_metadata["subject_area"] = parsed_ddl.get("table_name")

        # Process columns
        attributes, metrics = self.process_columns(parsed_ddl)
        self.final_metadata["attributes"] = attributes
        self.final_metadata["metrics"] = metrics

        return self.final_metadata

    def process_columns(self, parsed_ddl: dict) -> tuple:
        attributes = {}
        metrics = {}
        for column in parsed_ddl.get("columns", []):
            col_name = column["name"]
            col_type = column["type"].lower()

            base_entry = {
                "table": f"{parsed_ddl.get('schema', 'default')}."
                + f"{parsed_ddl.get('table_name', 'unknown')}",
                "name": col_name.replace("_", " ").title(),
                "type": col_type,
                "column": col_name,
                "desc": col_name.replace("_", " ").title(),
            }

            if self.is_metric(col_type):
                metric_entry = base_entry.copy()
                metric_entry["function"] = "sum"
                metrics[col_name] = metric_entry
            else:
                attribute_entry = base_entry.copy()
                attribute_entry["primary_key"] = col_name in parsed_ddl.get(
                    "primary_key", []
                )
                attributes[col_name] = attribute_entry

        return attributes, metrics

    def is_metric(self, col_type: str) -> bool:
        """
        Determine if a column is a metric based on its SQL data type.
        """
        numeric_types = [
            "int",
            "integer",
            "smallint",
            "bigint",
            "tinyint",
            "decimal",
            "numeric",
            "float",
            "real",
            "double",
            "number",
            "money",
            "smallmoney",
        ]
        return any(numeric_type in col_type for numeric_type in numeric_types)
