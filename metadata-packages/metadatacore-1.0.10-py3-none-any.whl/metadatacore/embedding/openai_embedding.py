from langchain_openai import OpenAIEmbeddings
from typing import List
from .base import BaseEmbedding
import numpy as np
from decouple import config
import openai
from metadatacore.logging.logger import create_logger

logger = create_logger(level="DEBUG")

# Download stopwords and the tokenizer
# nltk.download('punkt')
# nltk.download('punkt-tab')
# nltk.download('stopwords')
# nltk.download('wordnet')
# python -m spacy download en_core_web_sm

EMBEDDING_SIZE = config('EMBEDDING_SIZE', default=None)


class OpenAIEmbedding(BaseEmbedding):
    def __init__(self, threshold=0.9):
        super().__init__()
        openai.api_key = config("API_KEY")
        self.model = OpenAIEmbeddings(model="text-embedding-3-small", dimensions=EMBEDDING_SIZE, openai_api_key=config("API_KEY"))
        self.threshold = threshold

    def get_similarity(self, embeddings1, embeddings2):
        return self.calculate_cosine_similarity_batch(embeddings1, embeddings2)

    def embed(self, text: str | list[str]):
        logger.info(f"Embedding text: {text}")
        return np.array(self.model.embed_documents(text))
    
    def get_openai_embedding(self,text):
        """
        Generate an embedding using OpenAI's API
        
        :param text: Input text to embed
        :return: Embedding vector
        """
        return self.model.embed_query(text)
