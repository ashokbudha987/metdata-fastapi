import logging
from logging.handlers import RotatingFileHandler

class EmbeddingLogger:
    """
    A class-based logger that logs messages to a file called embedding.log.
    """

    def __init__(self, log_file="embedding.log", max_bytes=5*1024*1024, backup_count=5):
        """
        Initializes the logger.

        Args:
            log_file (str): Path to the log file.
            max_bytes (int): Maximum size of the log file before rotation.
            backup_count (int): Number of backup log files to keep.
        """
        self.logger = logging.getLogger("EmbeddingLogger")
        self.logger.setLevel(logging.INFO)

        handler = RotatingFileHandler(log_file, maxBytes=max_bytes, backupCount=backup_count)
        formatter = logging.Formatter('%(asctime)s - %(message)s')
        handler.setFormatter(formatter)

        if not self.logger.hasHandlers():
            self.logger.addHandler(handler)

    def log(self, message):
        """
        Logs the key and embedding.
        """
        print(message)
        self.logger.info(f"detail:{message}")
