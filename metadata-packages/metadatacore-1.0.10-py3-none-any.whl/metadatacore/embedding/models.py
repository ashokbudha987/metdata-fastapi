from sqlalchemy import Column, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import declarative_base
from pgvector.sqlalchemy import Vector
import uuid

Base = declarative_base()

class MetadataEmbedding(Base):
    """
    SQLAlchemy ORM model for storing metadata embeddings
    """
    __tablename__ = 'metadata_embeddings'

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, unique=True, nullable=False)
    term = Column(String, nullable=False)
    term_key = Column(String, nullable=False)
    agent_id = Column(String, nullable=False)  
    user_id = Column(String, nullable=False)    
    metadata_word_combo = Column(String, nullable=False)
    metadata_hash = Column(String, nullable=False)
    terms_embedding = Column(Vector(dim=32), nullable=False)

    def __repr__(self):
        return f"<MetadataEmbedding(term='{self.term}', term_key='{self.term_key}')>"