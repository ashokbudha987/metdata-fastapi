from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from decouple import config
from .models import Base, MetadataEmbedding
from typing import List
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError

class DatabaseManager:
    """
    Manages database connection and session creation
    """
    _instance = None

    def __new__(cls):
        if not cls._instance:
            cls._instance = super(DatabaseManager, cls).__new__(cls)
            cls._instance._initialize()
        return cls._instance

    def _initialize(self):
        """
        Initialize database connection and session factory
        """
        try:
            # Construct database URL
            db_url = f"postgresql://{config('DATABASE_USER')}:{config('DATABASE_PASSWORD')}@{config('DATABASE_HOST')}:{config('DATABASE_PORT', default='5432')}/{config('DATABASE_NAME')}"
            
            # Create engine
            self.engine = create_engine(db_url)
            
            # Create all tables
            Base.metadata.create_all(self.engine)
            
            # Create session factory
            self.SessionLocal = sessionmaker(bind=self.engine)
        except Exception as e:
            print(f"Database connection error: {e}")
            self.engine = None
            self.SessionLocal = None


    def get_session(self):
        """
        Get a new database session
        """
        if not self.SessionLocal:
            raise RuntimeError("Database not initialized")
        return self.SessionLocal()
    
    