from abc import ABC, abstractmethod
import string
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer, WordNetLemmatizer
from nltk.tokenize import word_tokenize
from itertools import combinations, permutations
import numpy as np # type: ignore
import re
from typing import Union, List
import uuid  
import hashlib
import json
from rapidfuzz.fuzz import ratio
from functools import lru_cache


class BaseEmbedding(ABC):
    def __init__(self, threshold=0.9):
        self.stemmer = PorterStemmer()
        self.lemmatizer = WordNetLemmatizer()
        self.threshold = threshold


    @abstractmethod
    def embed(self, text: str | list[str]):
        pass

    @abstractmethod
    def get_similarity(self, embeddings1, embeddings2):
        pass

    @staticmethod
    def calculate_cosine_similarity_batch(
            embeddings1: Union[List[float], List[List[float]]],
            embeddings2: Union[List[float], List[List[float]]] = None
    ) -> np.ndarray | float:
        """
        Calculate cosine similarity between embeddings, handling both single vectors and batches.

        Args:
            embeddings1: First embedding or list of embeddings
            embeddings2: Second embedding or list of embeddings (optional, if None compares embeddings1 with itself)

        Returns:
            np.ndarray: Similarity matrix where each element [i,j] represents the
                       cosine similarity between ith embedding of embeddings1 and
                       jth embedding of embeddings2
        """
        arr1 = np.array(embeddings1)

        if arr1.ndim == 1:
            arr1 = arr1.reshape(1, -1)

        if embeddings2 is None:
            arr2 = arr1
        else:
            arr2 = np.array(embeddings2)
            if arr2.ndim == 1:
                arr2 = arr2.reshape(1, -1)

        if arr1.shape[1] != arr2.shape[1]:
            raise ValueError(f"Embedding dimensions do not match: {arr1.shape[1]} != {arr2.shape[1]}")

        norms1 = np.linalg.norm(arr1, axis=1)
        norms2 = np.linalg.norm(arr2, axis=1)

        norms1[norms1 == 0] = np.inf
        norms2[norms2 == 0] = np.inf

        dot_product = np.dot(arr1, arr2.T)
        norms_product = np.outer(norms1, norms2)
        similarities = dot_product / norms_product

        similarities = np.clip(similarities, -1.0, 1.0)
        return similarities


    def get_stems(self, terms: list[str]) -> list[str]:
        return [self.stemmer.stem(word) for word in terms]


    def get_lemmatization(self, terms: list[str] | str) -> list[str]:
        return [self.lemmatizer.lemmatize(word) for word in terms]


    def remove_stop_words(self, query):
        filtered_sentence = "".join(
            [char for char in query if char not in string.punctuation]
        )
        words = word_tokenize(filtered_sentence)
        stop_words = set(stopwords.words("english"))
        filtered_stop_word_sentence = [
            word for word in words if word.lower() not in stop_words
        ]
        filtered_stop_word_sentence = " ".join(filtered_stop_word_sentence)
        return filtered_stop_word_sentence


    @staticmethod
    def generate_combinations(words: list[str]) -> list[str]:
        combos: list[str] = []
        max_length = min(5, len(words)) 
        for r in range(1, max_length + 1):  
            for combo in combinations(words, r):
                combos.append(" ".join(combo))
        return combos


    def get_combinations(self, words, final_metadata):
        """
        Generate combinations of words given a list of words and the final metadata.

        The list of words is split into individual words, and all combinations of the words
        are generated. The combinations are then filtered to only include those that contain
        at least one valid metadata element.

        Args:
            words (list[str]): A list of words to generate combinations from.
            final_metadata (dict): The final metadata to filter combinations against.

        Returns:
            list[str]: A list of valid combinations of the input words.
        """
        metadata = []
        metadata_elements = []
        refined_metadata = []
        final_response = []
        symbols_removed = []
        combos = []

        metadata = self.metadata_to_list(final_metadata)
        #print(f"Metadata: {metadata}")
        metadata_elements = self.extract_metadata_elements(metadata)
        #print(f"Metadata elements: {metadata_elements}")

        refined_metadata = self.sanitize_list(metadata_elements)
        #print(f"refined_metadata: {refined_metadata}")

        final_response = self.remove_stop_words_and_lemmatize(refined_metadata)
        #print(f"final_response: {final_response}")

        symbols_removed = self.remove_math_symbols_and_split(final_response)
        #print(f"symbols_removed: {symbols_removed}")

        single_symbols_removed = [single for phrase in symbols_removed for single in phrase.split()]
        words = [filtered_word for filtered_word in words if filtered_word in single_symbols_removed]
        words = list(set(words))
        #print(f"words: {words}")
        combos: list[str] = []
        if len(words) < 5:
            max_length = len(words)
            for r in range(1, max_length + 1):  
                for combo in combinations(words, r):
                    combos.append(" ".join(combo))
                    #combos.append(" ".join(reversed(combo)))
                    # for perm in permutations(combo):
                    #     combos.append(" ".join(perm))
            #print(f"combinations: {combos}")
            #print(f"possible combos: {len(combos)}")
            response = self.retain_elements(combos, symbols_removed)
            response = list(set(response))
            #print(f"response: {response}")
            #print(len(response))
            return response
        elif len(words) < 10: 
            matches = []
            reversed_matches = []
            matches = self.find_valid_combinations(symbols_removed, words)
            matches = list(set(matches))
            matches = self.filter_elements(words, matches)

            # reversed_words = words[::-1]
            # reversed_matches = self.find_valid_combinations(symbols_removed, reversed_words)
            # reversed_matches = list(set(reversed_matches))
            # reversed_matches = self.filter_elements(words, reversed_matches)

            # final_matches = list(set(matches + reversed_matches))
            #print(f"Matches: {matches}")
            return matches
        else:
            matches = []
            reversed_matches = []
            matches = self.find_valid_combinations_dict(symbols_removed, words)
            matches = list(set(matches))
            matches = self.filter_elements(words, matches)

            # reversed_words = words[::-1]
            # reversed_matches = self.find_valid_combinations_dict(symbols_removed, reversed_words)
            # reversed_matches = list(set(reversed_matches))
            # reversed_matches = self.filter_elements(words, reversed_matches)

            # final_matches = list(set(matches + reversed_matches))
            #print(f"Matches: {matches}")
            return matches



    def filter_elements(self, A, B):
        """
        Filter a list of phrases (B) to only include phrases that consist
        entirely of words present in another list (A).

        Args:
            A (list[str]): List of valid words.
            B (list[str]): List of phrases to filter.

        Returns:
            list[str]: Filtered list of phrases.
        """
        filtered_B = []
        valid_words = set(A)  
        filtered_B = [
            phrase for phrase in B 
            if all(word in valid_words for word in phrase.split())
        ]
        return filtered_B
    


    def build_metadata_trie(self, metadata, valid_words):
        trie = {}
        for phrase in metadata:
            node = trie
            for word in phrase.split():
                if word not in valid_words:
                    continue
                if word not in node:
                    node[word] = {}
                node = node[word]
            node["_end_"] = True
        return trie

    def search_trie(self, trie, words):
        node = trie
        for word in words:
            if word not in node:
                return False, False
            node = node[word]
        return True, "_end_" in node


    def find_valid_combinations(self, metadata, word_list):
        valid_words = set(word_list)  
        trie = self.build_metadata_trie(metadata, valid_words)
        normalized_metadata = {" ".join(sorted(phrase.split())) for phrase in metadata}

        def backtrack(start, current_combination):
            for perm in permutations(current_combination):
                is_valid_prefix, is_complete_phrase = self.search_trie(trie, perm)
                if not is_valid_prefix: 
                    continue
                joined_combination = " ".join(sorted(perm))  
                if is_complete_phrase and joined_combination in normalized_metadata:
                    valid_combinations.append(" ".join(perm))

            for i in range(start, len(word_list)):
                backtrack(i + 1, current_combination + [word_list[i]])

        valid_combinations = []
        backtrack(0, [])
        return valid_combinations


    

    def build_metadata_set_dict(self, metadata, valid_words):
        metadata_dict = {}
        for phrase in metadata:
            word_set = frozenset(phrase.split())  
            if word_set.issubset(valid_words):
                metadata_dict[word_set] = phrase
        return metadata_dict


    def find_valid_combinations_dict(self, metadata, word_list):
        valid_words = set(word_list)
        metadata_dict = self.build_metadata_set_dict(metadata, valid_words)
        valid_combinations = []
        
        def backtrack(start, current_combination):
            current_set = frozenset(current_combination)
            if current_set in metadata_dict:
                valid_combinations.append(" ".join(current_combination))
            
            for i in range(start, len(word_list)):
                backtrack(i + 1, current_combination + [word_list[i]])

        backtrack(0, [])
        return list(set(valid_combinations))


    def retain_elements(self, combos, symbols_removed):
        def is_single_word(item):
            return len(item.split()) == 1

        matched_permutations = []

        def any_order_in_symbols(item):
            words = item.split()
            for perm in permutations(words):
                perm_string = " ".join(perm)
                if perm_string in symbols_removed:
                    #print(f"Matched Combination: '{item}' with '{perm_string}' in symbols_removed")
                    matched_permutations.append(perm_string)
                    return True
            return False

        filtered_combos = [item for item in combos if is_single_word(item) or any_order_in_symbols(item)]
        result = list(set(filtered_combos + matched_permutations))
        return result




    def metadata_to_list(self, metadata):
        """
        Converts the given metadata into a list of dictionaries containing the metric name, synonym, description, calculation and granularity.
        
        Args:
            metadata (list[dict]): A list of dictionaries, where each dictionary contains the metric name as the key and attributes as the value.
        
        Returns:
            list[dict]: A list of dictionaries containing the metric name, synonym, description, calculation and granularity.
        """
        if not isinstance(metadata, list):
            raise TypeError("Expected metadata to be a list of dictionaries.")
        
        metadata_list = []
        for item in metadata:
            if not isinstance(item, dict):
                raise ValueError("Each item in metadata should be a dictionary.")
            
            for metric, attributes in item.items():
                metric_details = {
                    "metric": metric,
                    "synonym": attributes.get("synonym", []),
                    "description": attributes.get("description", ""),
                    "calculation": attributes.get("calculation", ""),
                    "granularity": attributes.get("granularity", []),
                }
                metadata_list.append(metric_details)
        
        return metadata_list
    

    def extract_metadata_elements(self, metadata):
        unique_elements = set()

        def extract(value):
            """Recursively extract elements and add to the set."""
            if isinstance(value, dict):
                for v in value.values():
                    extract(v)
            elif isinstance(value, list):
                for item in value:
                    extract(item)
            else:
                unique_elements.add(value)

        for entry in metadata:
            extract(entry)
        return list(unique_elements)
    

    def sanitize_list(self, elements):
        sanitized_list = []

        for element in elements:
            if isinstance(element, str):
                sanitized = element.replace("_", " ")
                sanitized = re.sub(r"\[([^\]]+)\]", r"\1", sanitized)
                sanitized = sanitized.strip()
                sanitized_list.append(sanitized)
            else:
                sanitized_list.append(element)

        return sanitized_list
    

    def remove_stop_words_and_lemmatize(self, terms_list):
        stop_words = set(stopwords.words('english'))
        lemmatizer = WordNetLemmatizer()

        def process_term(term):
            words = word_tokenize(term)
            processed_words = [lemmatizer.lemmatize(word.lower()) for word in words if word.lower() not in stop_words]
            return ' '.join(processed_words)

        return [process_term(term) for term in terms_list]
    

    def remove_math_symbols_and_split(self, terms_list):
        processed_terms = []
        for term in terms_list:
            split_terms = re.split(r'[+\-*/.]', term)
            split_terms = [term.strip() for term in split_terms if term.strip()]
            processed_terms.extend(split_terms)  
        return processed_terms
    


    @staticmethod
    def get_terms_from_dict(meta_dicts: dict):
        terms: list[str] = []
        terms_key: list[str] = []

        for key, value in meta_dicts.items():
            name: str = value.get("name", "")
            synonyms: list[str] = value.get("synonym", [])

            if name:
                terms.append(name)
                terms_key.append(key)

            for synonym in synonyms:
                terms.append(synonym)
                terms_key.append(key)

        processed_terms = []
        processed_term_keys = []
        lemmatizer = WordNetLemmatizer()

        for term in terms:
            term = term.lower()
            tokenized_term = word_tokenize(term)
            lematized_term = [lemmatizer.lemmatize(word) for word in tokenized_term]
            processed_terms.append(" ".join(lematized_term)) 

        # for term_key in terms_key:
        #     term_key = term_key.lower()
        #     tokenized_term_key = word_tokenize(term)
        #     lematized_term_key = [lemmatizer.lemmatize(word_key) for word_key in tokenized_term_key]
        #     processed_term_keys.append(" ".join(lematized_term_key)) 

        return processed_terms, terms_key

    def combo_embeddings_for_query(self, query, final_metadata):
            sentence = self.remove_stop_words(query)
            sentence_words = word_tokenize(sentence)
            lemmatized_words = self.get_lemmatization(sentence_words)

            word_combo = self.get_combinations(lemmatized_words, final_metadata)
            
            #self.get_combinations(lemmatized_words, final_metadata)
            #combo_embeddings = self.embed(word_combo)
            return word_combo
    
    
    def filter_metadata(self, metadata, query_embeddings):
        terms, terms_stop_words_removed_lemmatized, terms_key = self.meta_terms_embedding(metadata)
        metadata_hash = "sha256"
        for term, term_key, lemmatized_term in zip(terms, terms_key, terms_stop_words_removed_lemmatized):
            self.embedding_ops.upsert_embedding(
                term=term,
                term_key=term_key,
                metadata_word_combo="test_combo",
                metadata_hash=metadata_hash,
                terms_stop_words_removed_lemmatized=lemmatized_term,
                agent_id="AgentX",
                user_id="UserX"
            )
        
        matches = []
        match_keys = []
        similarity_scores = []
        for combo_embedding in query_embeddings:
            top_similar = self.embedding_ops.get_top_similar_embeddings(query_embedding=combo_embedding, metadata_hash=metadata_hash)
                        
            if top_similar['data']:
                for result in top_similar['data']:
                    matches.append(result['term'])
                    match_keys.append(result['term_key'])
                    similarity_scores.append(result['similarity']) 
                            
        match_keys = list(set(match_keys))
        metadata_filtered = {}
        
        for match_key in match_keys:
            metadata_filtered[match_key] = metadata[match_key]

        return metadata_filtered
    


    def get_filtered_metadata(self, metadata, query_embeddings):
        terms, terms_key = self.get_terms_from_dict(metadata)
        similarity_threshold = 100
        matches = []
        match_keys = []
        
        for combo_embedding in query_embeddings:
            #print(f"COMBO EMBEDDING: {combo_embedding}")
            for i in range(len(terms)):
                #print(f"TERM: {terms[i]}")
                similarity = ratio(combo_embedding, terms[i])
                if similarity >= similarity_threshold:
                    #print(f"{terms[i]}, {terms_key[i]}")
                    matches.append(terms[i])
                    match_keys.append(terms_key[i])

        metadata_filtered = {key: metadata[key] for key in list(set(match_keys))}
        #print(f"METADATA FILTERED: {metadata_filtered}")
        return metadata_filtered
    

    # @lru_cache(maxsize=128)
    def meta_terms_embedding(self, metadata):
        terms, terms_key = self.get_terms_from_dict(metadata)
        terms_stop_words_removed = [self.remove_stop_words(term) for term in terms]
        terms_stop_words_removed_lemmatized = []
        for term in terms_stop_words_removed:
            tokens = word_tokenize(term.lower())
            lemmatized_tokens = self.get_lemmatization(tokens)
            terms_stop_words_removed_lemmatized.append(" ".join(lemmatized_tokens))

        terms = [term.lower() for term in terms]
        terms_stop_words_removed_lemmatized = [element.lower() for element in terms_stop_words_removed_lemmatized]
        terms_key = [term_key.lower() for term_key in terms_key]
        return terms, terms_stop_words_removed_lemmatized, terms_key
    

    def get_final_filtered_metadata(self, query, final_metadata):
        (
            final_metrics,
            final_attributes,
            final_columns,
            final_functions,
        ) = final_metadata
        final_metadata = [final_metrics, final_attributes, final_columns, final_functions]
        query_embeddings = self.combo_embeddings_for_query(query, final_metadata)
        
        filtered_metrics = (
            self.get_filtered_metadata(final_metrics, query_embeddings)
            if final_metrics is not None and final_metrics != {}
            else {}
        )
        filtered_attributes = (
            self.get_filtered_metadata(final_attributes, query_embeddings)
            if final_attributes is not None and final_attributes != {}
            else {}
        )
        filtered_columns = (
            self.get_filtered_metadata(final_columns, query_embeddings)
            if final_columns is not None and final_columns != {}
            else {}
        )
        filtered_functions = (
            self.get_filtered_metadata(final_functions, query_embeddings)
            if final_functions is not None and final_functions != {}
            else {}
        )

        return [
            filtered_metrics,
            filtered_attributes,
            filtered_columns,
            filtered_functions,
        ]