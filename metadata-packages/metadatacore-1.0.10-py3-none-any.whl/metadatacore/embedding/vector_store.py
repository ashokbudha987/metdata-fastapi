from typing import List
from metadatacore.utils.helpers import capture_execution_time
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError
from .database import DatabaseManager
from .models import MetadataEmbedding
from .logger import EmbeddingLogger
from decouple import config
import time

class EmbeddingOperations:
    """
    Handles embedding-related database operations
    """
    def __init__(self):
        self.openai_embedding = None
        self.db_manager = DatabaseManager()
        self.logger = EmbeddingLogger()
        
    def initialize_openai_embedding(self):
        from .openai_embedding import OpenAIEmbedding  # Import here to avoid circular import
        self.embed= OpenAIEmbedding()  # create an instance
        

    def upsert_embedding(self, term, term_key, metadata_word_combo, metadata_hash, terms_stop_words_removed_lemmatized, agent_id, user_id):
        self.initialize_openai_embedding()
        with self.db_manager.get_session() as session:
            # Check if the metadata_hash already exists
            existing_embedding = session.query(MetadataEmbedding).filter_by(term=term, term_key=term_key).first()
            
            if existing_embedding:
                if existing_embedding.metadata_hash == metadata_hash:
                    return None
                
                # Calculate  embedding
                terms_embedding = self.embed.get_openai_embedding(terms_stop_words_removed_lemmatized)                
                existing_embedding.terms_embedding = terms_embedding
                existing_embedding.metadata_hash = metadata_hash
                session.commit()
                

            else:
                # Insert new record
                terms_embedding = self.embed.get_openai_embedding(terms_stop_words_removed_lemmatized)  
                new_embedding = MetadataEmbedding(
                    term=term,
                    term_key=term_key,
                    metadata_word_combo=metadata_word_combo,
                    metadata_hash=metadata_hash,
                    terms_embedding=terms_embedding,
                    agent_id = agent_id,
                    user_id=user_id
                )
                session.add(new_embedding)
                session.commit()
                
                
        
    @capture_execution_time
    def get_top_similar_embeddings(
        self, 
        query_embedding: List[float],
         metadata_hash, 
        top_n: int = 5
    ):
        """
        Retrieves top similar embeddings using cosine similarity enforcing a specified threshold. 

        Parameters:
            a. query_embedding(list[float]): Vector embedding for the query/question.
            b. top_n(int): Number of embeddings to return that fulfill the similarity threshold.

        Returns:
            {message:text, error: text, data: list[dict]}
                list[dict]: [{"term","term_key","embedding","similarity"}]
        """
        session = self.db_manager.get_session()
        
        try:
            results = session.query(
                MetadataEmbedding.term,
                MetadataEmbedding.term_key,
                MetadataEmbedding.metadata_word_combo,
                MetadataEmbedding.terms_embedding,
                (1 - MetadataEmbedding.terms_embedding.cosine_distance(query_embedding)).label('cosine_similarity')
            ).filter(
                (MetadataEmbedding.metadata_hash == metadata_hash) &  # Filter by metadata_hash
                ((1 - MetadataEmbedding.terms_embedding.cosine_distance(query_embedding)) >= config("SIMILARITY_THRESHOLD", cast=float))
            ).order_by(
                text('cosine_similarity desc')
            ).limit(top_n).all()
            return {
                "message": "Fetched sucessfully!",
                "error": None,
                "data": [
                    {
                        "term": row.term,
                        "term_key": row.term_key,
                        "embedding": list(
                            map(lambda x: round(x, 6), row.terms_embedding.tolist())
                        ),
                        "similarity": row.cosine_similarity,
                    }
                    for row in results
                ],
            }
        except SQLAlchemyError as e:
            self.logger.log(f"error:{str(e)}")
            return {
                "message": "Could not fetch similar embeddings.",
                "error": str(e),
                "data": None,
            }
        finally:
            session.close()

    def get_all_terms(self):
        """Get all terms from the database.
        """
        session = self.db_manager.get_session()
        try:
            results = session.query(MetadataEmbedding.term).all()
            return {
                "message": "Fetched sucessfully!",
                "error": None,
                "data": [row.term for row in results],
                }
        except SQLAlchemyError as e:
            self.logger.log(f"error:{str(e)}")
            return {
                "message": "Could not fetch keys.",
                "error": str(e),
                "data": None,
            }
        finally:
            session.close()
