from typing import Any, Dict

import yaml


class Helpers:
    @staticmethod
    def read_yaml_file(file_path: str) -> Dict[str, Any]:
        """
        Reads and parses a YAML file into a dictionary.

        Args:
            file_path (str): The path to the YAML file to be read.

        Returns:
            Dict[str, Any]: The parsed YAML file as a dictionary.
        """
        try:
            with open(file_path, "r") as file:
                return yaml.safe_load(file)
        except FileNotFoundError:
            raise FileNotFoundError(f"File {file_path} not found.")
        except Exception as e:
            raise Exception(f"Error reading file {file_path}: {e}")
