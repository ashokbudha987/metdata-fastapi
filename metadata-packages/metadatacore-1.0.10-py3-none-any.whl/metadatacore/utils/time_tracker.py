import time
from functools import wraps

from metadatacore.logging.logger import create_logger

logger = create_logger(level="DEBUG")


def capture_execution_time(func):
    """
    A decorator function to capture the execution time of a given function.

    Args:
        func: The function to be decorated.

    Returns:
        A wrapper function that captures the execution time of the given function.
    """

    @wraps(func)
    def wrapper(*args, **kwargs):
        """
        This function is a wrapper that captures the execution time of the provided function.

        It takes in a variable number of positional and keyword arguments,
        calls the provided function with these arguments,
        and logs the time taken to execute the function.

        The result of the function call is then returned.

        Parameters:
            *args: A variable number of positional arguments to be passed to the function.
            **kwargs: A variable number of keyword arguments to be passed to the function.

        Returns:
            The result of the function call.
        """
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        logger.info("-" * 20)
        logger.info(f"Time taken to run {func.__name__}: {end_time - start_time}")
        logger.info("-" * 20)

        return result

    return wrapper
