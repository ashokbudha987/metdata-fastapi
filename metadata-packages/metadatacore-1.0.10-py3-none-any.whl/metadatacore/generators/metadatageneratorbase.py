from abc import ABC, abstractmethod
from itlm_db_connector.factory import DatabaseFactory
from decouple import config
from typing import Dict
import yaml
from simple_ddl_parser import DDLParser
from metadatacore.generators.metadatageneratorstrategy import LLMMetadataGenerator, PythonicMetadataGenerator
import requests
from collections import Counter
import requests
import chardet
import pandas as pd
import xmltodict
from io import BytesIO


class MetaDataGeneratorBase(ABC):
    """
        Abstract base class that provides the foundational structure for generating metadata from DDL (Data Definition Language) statements. It includes methods for initializing database connections, calling different metadata generation strategies, and writing the generated metadata to YAML files.

        Methods:
        __init__(self, config):
        Initializes the metadata generator with the necessary database configuration. It sets up the database connection using the DatabaseFactory and configures Snowflake-specific settings.

        call_generator(self, parsed_ddl, method="manual", ddl=""):
        Calls the appropriate metadata generator based on the specified method. It supports two methods: "pythonic" and "llm". If an undefined method is provided, the program exits.

        write_to_file(self, results, subject_area):
        Writes the generated metadata to a YAML file. The file is saved in the "outputs" directory with a filename based on the subject area.
    """

    def __init__(self):
        self._name = "Metadata Generator"

    def call_generator(self, input_data: Dict = None, method="manual"):
        if not input_data:
            raise ValueError("Input data cannot be None. Please provide a valid data source.")
        
        method_map = {
            "pythonic": PythonicMetadataGenerator,
            "llm": LLMMetadataGenerator
        }
        
        generator_class = method_map.get(method)
        if not generator_class:
            raise ValueError(f"Undefined method '{method}'. Supported methods are: {list(method_map.keys())}.")
         
        if method =="pythonic":
            py_generate = PythonicMetadataGenerator()
            return py_generate.generate(input_data)
        elif method=="llm":
            llm_generate = LLMMetadataGenerator()
            return llm_generate.generate(input_data)
        else:
            return None
                    
                    

class DBMetadataGenerator(MetaDataGeneratorBase):
    """
        MetadataGeneratorForDB is a class that extends MetaDataGeneratorBase to provide functionality for extracting and processing metadata from a database.
        It initializes a database connection  and provides methods to extract DDLs for all tables or specific subject areas, process these DDLs, and write the generated metadata to YAML files.

        Methods:
            - __init__(): Initializes the database connection using Snowflake configurations.
            - extract_all_tables_and_ddls(): Extracts all tables and their DDLs from the database.
            - extract_ddl_for_subject_areas(tables): Extracts DDLs for specified tables.
            - process_tables_from_config(config_tables): Processes tables specified in the configuration file.
            - process_ddls(ddls): Processes a list of DDLs and returns metadata results.
"""
    # self.database = DatabaseFactory().select_database(config('DATABASE'))

    def __init__(self, **db_config):
        super().__init__()
        #Database connection

        db_type = db_config.get('database_type')       
        database_obj = DatabaseFactory().get_connector(db_type)
        self.database = database_obj(**db_config)   

    def extract_all_tables_and_ddls(self):
        """
        Extract all tables and their respective DDLs from the database.

        Returns:
            dict: A dictionary with table names as keys and their DDLs as values.
        """
        ddl_dictionary = {}
        table_names = self.database.fetch_table_from_db()

        for table in table_names:
            ddl = self.database.get_ddl(table.get('name'))
            if ddl:
                ddl_dictionary[table.get('name')] = ddl
            else:
                raise ValueError(f"No DDL found for table: {table}")

        return ddl_dictionary

    def extract_ddl_for_subject_areas(self, tables):
        """
        Extracts the DDL for the given tables.

        Args:
            tables (list): A list of table names.

        Returns:
            list: A list of DDL strings for the specified tables.
        """
        ddls = []
        for table in tables:
            ddl = self.database.get_ddl(table)
            if ddl:
                ddls.append(ddl)

        return ddls

    def process_tables_from_config(self, config_tables):
        """
        Process tables specified in the configuration file.

        Args:
            config_tables (dict): A dictionary with subject areas as keys and table lists as values.
        """
        for subject_area, tables in config_tables.items():
            ddls = self.extract_ddl_for_subject_areas(tables)

            if not ddls:
                raise ValueError(f"No DDL found for tables: {tables}")

            results = self.process_ddls(ddls)

            self.write_to_file(results, subject_area)

    def process_ddls(self, ddls):
        """
        Process a list of DDLs.

        Args:
            ddls (list): List of DDL strings.

        Returns:
            list: List of metadata results.
        """
        results = []
        for ddl in ddls:
            parsed_ddl = DDLParser(ddl).run(output_mode="hql")

            if not parsed_ddl:
                # print(f"Failed to parse DDL: {ddl}")
                continue

            result = self.call_generator(
                parsed_ddl[0], config('GENERATOR_TYPE'), ddl)
            results.append(result)

        return results



class DSVMetadataGenerator(MetaDataGeneratorBase):    
    def fetch_dsv_file(self,file_url=None, start_byte=0, end_byte=5000):
        """
        Fetches specified bytes of remote dsv file.

        Args:
            1. file_url(str): URL to the file to be fetched
            2. start_byte(int): Lower byte index
            3. end_byte(int): Upper byte limit

        Returns:
            dict: {"error": str, "fetched": bool, "response": http response}
        """

        headers = {'Range': f'bytes={start_byte}-{end_byte}'}
        response = requests.get(file_url, headers=headers, stream=True)
        if response.status_code not in [200, 206]:
            return {
                "error": f"Failed to fetch file. Status code: {response.status_code}",
                "fetched": False,
                "response": None
            }
        
        return {
                "error": None,
                "fetched": True,
                "response": response
            }
        

    def check_file_validity(self,file_url):
        """
        Checks if the txt file is valid:
            1. Has valid delimiter.
            2. Detects the file encoding.

        Args:
            1. file_path(str): Path to the file to be validated.

        Returns:
            1. dict:{
                    "error": str,
                    "file_valid": bool,
                    "delimiter": char,
                    "file_encoding": str,
                }
        """

        response_dict = self.fetch_dsv_file(file_url=file_url)

        if not response_dict.get("fetched"):
            return {
                "error": response_dict.get("error"),
                "file_valid": False,
            }
        
        response = response_dict.get("response")
        content = response.text
        lines = content.splitlines()

        if not lines:
            return {"error": "File is empty", "file_valid": False}

        delimiter_obj = self.check_delimiter(file_lines=lines)
        if not delimiter_obj.get("delimiter_found"):
            return {"error": delimiter_obj.get("error"), "file_valid": False}

        delimiter = delimiter_obj.get("delimiter")
        file_encoding = self.get_file_encoding(file_content=response.content)
        return {
            "error": None,
            "file_valid": True,
            "delimiter": delimiter,
            "file_encoding": file_encoding,
        }


    def check_delimiter(self,file_lines):
        """
        Checks for a consistent delimiter used in the file

        Args:
            1. file_lines(list): List of lines read from a file.

        Returns:
            1. dict:{
                    "error": str,
                    "delimiter_found": bool,
                    "column_numbers": int,
                    "delimiter": char,
                }
        """
        valid_delimiters = [",", "#", ";", ":", "\t", " ", "|"]
        first_line = file_lines[0]
        delimiter_counts = Counter(ch for ch in first_line if ch in valid_delimiters)

        if not delimiter_counts:
            return {
                "error": "Cannot determine a consistent delimiter",
                "delimiter_found": False,
                "column_numbers": None,
                "delimiter": None,
            }

        delimiter, _ = delimiter_counts.most_common(1)[0]
        column_numbers = len(first_line.split(delimiter))

        return {
            "error": None,
            "delimiter_found": True,
            "column_numbers": column_numbers,
            "delimiter": delimiter,
        }


    def get_file_encoding(self, file_content):
        """
        Returns file encoding standard.

        Args:
            1. file_content(bytes): file content read in binary mode.

        Returns:
            file_encoding(str): Encoding standard used for the file.
        """

        file_encoding = chardet.detect(file_content).get("encoding", "utf-8")
        return file_encoding
    
    def get_dataframe(self,file_url):
        """
        Gets the pandas dataframe from the validated file

        Args:
            1. file_path(str): Path to the file.

        Returns:
            1. dict:{
                    "error": str,
                    "file_valid": bool,
                    "dataframe": pandas.core.frame.DataFrame,
                }
        """

        validity_obj = self.check_file_validity(file_url=file_url)
        if not validity_obj.get("file_valid"):
            return {
                "error": validity_obj.get("error"),
                "file_valid": False,
                "dataframe": None,
            }
        try:
            df = pd.read_csv(
                file_url,
                sep=validity_obj.get("delimiter"),
                encoding=validity_obj.get("file_encoding"),
            )
        except Exception as e:
            return {"error": f"Failed to read the file: {str(e)}", "file_valid": False}

        return {"error": None, "file_valid": True, "dataframe": df}


    def generate_data_content_structure(self, dataframe):
        """
        Generates data content structure for a given dataframe.

        Args:
            1. dataframe(pandas.core.frame.DataFrame): DataFrame for which content structure is to be generated.

        Returns:
            1. list: A list of dictionaries where each dictionary represents a column in the dataframe with keys as column_name and column_pandas_datatype.
        """
        content_structure = []
        
        for column in dataframe.columns:
            content_struct = {
                "column_name": column,
                "column_pandas_datatype": dataframe.dtypes[column]
            }
            content_structure.append(content_struct)
        return content_structure


    def get_sample_data(self, dataframe):
        """
        Retrieves a subset of sample data from a DataFrame.

        Args:
            dataframe (pandas.core.frame.DataFrame): The DataFrame from which to extract sample data.

        Returns:
            list: A list of lists representing the sample data, containing rows 2 to 6 from the DataFrame.
        """

        data_list = dataframe.values.tolist()

        return data_list[1:6]

    def generate_metadata(self, file_url):
        """
        Wrapper function to wrap helper functions for metadata generation.

        Args:
            1. file_url(str): URL to the dsv file for which metadata is to be generated.

        Returns:
            1. dict: The generated metadata.

        Raises:
            1. Exception: If the file is not valid or if the file is empty.
        """

        file_dataframe_obj = self.get_dataframe(file_url=file_url)
        if not file_dataframe_obj.get("file_valid"):
            raise Exception(file_dataframe_obj.get("error"))
        file_dataframe = file_dataframe_obj.get("dataframe")
        data_content_structure = self.generate_data_content_structure(dataframe=file_dataframe)
        result = self.call_generator(method=config('GENERATOR_TYPE'), input_data={'dsv':data_content_structure})
        return result


        

class JSONMetadataGenerator(MetaDataGeneratorBase):
    def fetch_json_file(self, file_url=None):
        """
        Fetches specified bytes of remote json file.

        Args:
            1. file_url(str): URL to the file to be fetched
            2. start_byte(int): Lower byte index
            3. end_byte(int): Upper byte limit

        Returns:
            dict: {"error": str, "fetched": bool, "response": http response}
        """

        response = requests.get(file_url, stream=True)
        if response.status_code not in [200, 206]:
            return {
                "error": f"Failed to fetch file. Status code: {response.status_code}",
                "fetched": False,
                "response": None
            }
        
        return {
                "error": None,
                "fetched": True,
                "response": response
            }
        

    def check_json_validity(self,json_file_url):

        """
        Checks if the JSON file at the given URL is valid and returns a pandas DataFrame.

        Args:
            json_file_url (str): URL to the JSON file to be validated.

        Returns:
            dict: {
                "error": str,       # Error message if any error occurs, else None.
                "json_valid": bool, # True if the JSON file is valid and can be converted to DataFrame, else False.
                "content": pandas.DataFrame or None, # DataFrame derived from JSON file if valid, else None.
            }
        """

        response_obj = self.fetch_json_file(file_url=json_file_url)
        if not response_obj.get("fetched"):
            return {
                    "error": response_obj.get("error"),
                    "json_valid": False,
                    "content_structure": None,
                }

        json_content = response_obj.get("response").json()
        json_content_structure = self.get_json_column_structure(json_content=json_content)
        if json_content_structure is None:
                return {
                    "error": json_content_structure,
                    "json_valid": False,
                    "content_structure": None,
                }
        return {
            "error": None,
            "json_valid": True,
            "content_structure": json_content_structure,
        }

    def get_json_column_structure(self, json_content):
        """
        Generates a list of dictionaries where each dictionary contains the column name and its corresponding data type
        for a given JSON content. If a dictionary value is a list, processes the first item and includes the list type.

        Args:
            json_content (dict or list): The JSON content (list of dictionaries or a single dictionary).

        Returns:
            list: A list of dictionaries, each containing the column name and its data type.
        """
        content_structure = []

        def process_item(prefix, item, depth=3):
            """
            Recursively processes a JSON item and its sub-items to generate its column structure.

            Args:
                prefix (str): The prefix for the column name.
                item (dict or list): The JSON item (dictionary or list).
                depth (int): The depth to which the item should be processed. Defaults to 3. If 0, the processing is stopped.

            Returns:
                None
            """

            if depth == 0:
                content_structure.append({
                    "column_name": prefix,
                    "column_datatype": type(item).__name__
                })
                return
            
            if isinstance(item, dict):
                for key, value in item.items():
                    full_key = f"{prefix}_{key}" if prefix else key
                    if isinstance(value, list):
                        content_structure.append({
                            "column_name": full_key,
                            "column_datatype": "list"
                        })
                        if value: 
                            process_item(full_key, value[0], depth=depth - 1) 
                    elif isinstance(value, dict):
                        process_item(full_key, value, depth=depth - 1)
                    else:
                        content_structure.append({
                            "column_name": full_key,
                            "column_datatype": type(value).__name__
                        })
            elif isinstance(item, list):
                for sub_item in item:
                    process_item(prefix, sub_item, depth=depth - 1)

        if isinstance(json_content, list):
            for item in json_content:
                process_item("", item)
        elif isinstance(json_content, dict):
            process_item("", json_content)
        else:
            raise ValueError(f"Unsupported JSON structure")

        return f"""{content_structure}"""
    
    def generate_metadata(self, file_url):
        """
        Wrapper function to wrap helper functions for metadata generation.

        Args:
            1. file_url(str): URL to the JSON file for which metadata is to be generated.

        Returns:
            1. dict: The generated metadata.

        Raises:
            1. Exception: If the file is not valid JSON or if the file is empty.
        """

        result_obj = self.check_json_validity(json_file_url=file_url)
        if not result_obj.get("json_valid"):
            raise Exception(result_obj.get("error"))
        json_content_structure = result_obj.get("content_structure")
        result = self.call_generator(method=config('GENERATOR_TYPE'), input_data={'json':json_content_structure})
        return result
            

class YMLMetadataGenerator(MetaDataGeneratorBase):
    def fetch_yml_file(self, file_url=None):
        """
        Fetches specified bytes of remote yml file.

        Args:
            1. file_url(str): URL to the file to be fetched

        Returns:
            dict: {"error": str, "fetched": bool, "response": http response}
        """

        response = requests.get(file_url, stream=True)
        if response.status_code not in [200, 206]:
            return {
                "error": f"Failed to fetch file. Status code: {response.status_code}",
                "fetched": False,
                "response": None
            }
        
        return {
                "error": None,
                "fetched": True,
                "response": response
            }
        

    def check_yml_validity(self,yml_file_url):
        """
        Checks if the yml file is valid:
            1. Has valid delimiter.
            2. Detects the file encoding.

        Args:
            1. yml_file_url(str): URL to the file to be validated.

        Returns:
            1. dict:{
                    "error": str,
                    "yml_valid": bool,
                    "content_structure": dict,
                }
        """

        response_obj = self.fetch_yml_file(file_url=yml_file_url)
        if not response_obj.get("fetched"):
            return {
                    "error": response_obj.get("error"),
                    "yml_valid": False,
                    "content_structure": None,
                }

        yml_content = yaml.safe_load(response_obj.get("response").content)
        yml_content_structure = self.get_yml_column_structure(yml_content=yml_content)
        if yml_content_structure is None:
                return {
                    "error": yml_content_structure,
                    "yml_valid": False,
                    "content_structure": None,
                }
        return {
            "error": None,
            "yml_valid": True,
            "content_structure": yml_content_structure,
        }

    def get_yml_column_structure(self, yml_content):
        """
        Generates a list of dictionaries where each dictionary contains the column name and its corresponding data type
        for a given JSON content. If a dictionary value is a list, processes the first item and includes the list type.

        Args:
            json_content (dict or list): The JSON content (list of dictionaries or a single dictionary).

        Returns:
            list: A list of dictionaries, each containing the column name and its data type.
        """
        content_structure = []

        def process_item(prefix, item, depth=3):
            """
            Recursively processes a JSON item and its sub-items to generate its column structure.

            Args:
                prefix (str): The prefix for the column name.
                item (dict or list): The JSON item (dictionary or list).
                depth (int): The depth to which the item should be processed. Defaults to 3. If 0, the processing is stopped.

            Returns:
                None
            """

            if depth == 0:
                content_structure.append({
                    "column_name": prefix,
                    "column_datatype": type(item).__name__
                })
                return
            
            if isinstance(item, dict):
                for key, value in item.items():
                    full_key = f"{prefix}_{key}" if prefix else key
                    if isinstance(value, list):
                        content_structure.append({
                            "column_name": full_key,
                            "column_datatype": "list"
                        })
                        if value: 
                            process_item(full_key, value[0], depth=depth - 1) 
                    elif isinstance(value, dict):
                        process_item(full_key, value, depth=depth - 1)
                    else:
                        content_structure.append({
                            "column_name": full_key,
                            "column_datatype": type(value).__name__
                        })
            elif isinstance(item, list):
                for sub_item in item:
                    process_item(prefix, sub_item, depth=depth - 1)

        if isinstance(yml_content, list):
            for item in yml_content:
                process_item("", item)
        elif isinstance(yml_content, dict):
            process_item("", yml_content)
        else:
            raise ValueError(f"Unsupported YML structure")

        return f"""{content_structure}"""
    
    def generate_metadata(self, file_url):
        """
        Wrapper function to wrap helper functions for metadata generation.

        Args:
            1. file_url(str): URL to the YAML file for which metadata is to be generated.

        Returns:
            1. dict: The generated metadata.

        Raises:
            1. Exception: If the file is not valid YAML or if the file is empty.
        """

        result_obj = self.check_yml_validity(yml_file_url=file_url)
        if not result_obj.get("yml_valid"):
            raise Exception(result_obj.get("error"))
        yml_content_structure = result_obj.get("content_structure")
        result = self.call_generator(method=config('GENERATOR_TYPE'), input_data={'yml':yml_content_structure})
        return result
    
class XMLMetadataGenerator(MetaDataGeneratorBase):

    def get_dictionary_column_structure(self, dictionary_content):
        """
        Generates a list of dictionaries where each dictionary contains the column name and its corresponding data type
        for a given dictionary content. If a dictionary value is a list, processes the first item and includes the list type.

        Args:
            dictionary_content (dict or list): The dictionary content (list of dictionaries or a single dictionary).

        Returns:
            list: A list of dictionaries, each containing the column name and its data type.
        """

        content_structure = []
        def process_item(
            prefix,
            item,
            depth=config("CONTENT_STRUCTURE_EXTRACTION_DEPTH", cast=int, default=3),
        ):
            """
            Recursively processes a dictionary item and its sub-items to generate its column structure.

            Args:
                prefix (str): The prefix for the column name.
                item (dict or list): The dictionary item (dictionary or list).
                depth (int): The depth to which the item should be processed. Defaults to 3. If 0, the processing is stopped.

            Returns:
                None
            """

            if depth == 0:
                content_structure.append(
                    {"column_name": prefix, "column_datatype": type(item).__name__}
                )
                return

            if isinstance(item, dict):
                for key, value in item.items():
                    full_key = f"{prefix}_{key}" if prefix else key
                    if isinstance(value, list):
                        content_structure.append(
                            {"column_name": full_key, "column_datatype": "list"}
                        )
                        if value:
                            process_item(full_key, value[0], depth=depth - 1)
                    elif isinstance(value, dict):
                        process_item(full_key, value, depth=depth - 1)
                    else:
                        content_structure.append(
                            {
                                "column_name": full_key,
                                "column_datatype": type(value).__name__,
                            }
                        )
            elif isinstance(item, list):
                for sub_item in item:
                    process_item(prefix, sub_item, depth=depth - 1)

        if isinstance(dictionary_content, list):
            for item in dictionary_content:
                process_item("", item)
        elif isinstance(dictionary_content, dict):
            process_item("", dictionary_content)
        else:
            raise ValueError(f"Unsupported dictionary structure")

        return content_structure
    
    def fetch_xml_file(self, xml_file_url: str):
        """
        Fetches the specified xml file from the given URL.

        Args:
            1. xml_file_url(str): URL to the xml file to be fetched

        Returns:
            dict: {
                "error": str,       # Error message if any error occurs, else None.
                "fetched": bool,    # True if the xml file is successfully fetched, else False.
                "response": http response or None, # The response object if successfully fetched, else None.
            }
        """
        
        try:
            response = requests.get(xml_file_url)
            if response.status_code != 200:
                return {
                    "error": f"Could not fetch xml file, status code: {response.status_code}",
                    "fetched": False,
                    "response": None,
                }
            return {"error": None, "fetched": True, "response": response}
        except Exception as e:
            return {
                "error": f"Could not fetch xml file, {str(e)}",
                "fetched": False,
                "response": None,
            }


    def get_xml_content_structure(self, xml_file_url: str):
        """
        Fetches the xml content from the given url and returns its column structure.

        Args:
            xml_file_url (str): URL to the xml file to be fetched.

        Returns:
            dict: A dictionary with the following keys:
                - error (str): An error message if any error occurs, else None.
                - xml_content_structure (list of dict): A list of dictionaries where each dictionary represents a column in the xml content with keys as column_name and column_datatype.
                - valid (bool): True if the xml content is valid and can be converted to column structure, else False.
        """
        
        response = self.fetch_xml_file(xml_file_url)
        if not response["fetched"]:
            return {
                "error": response["error"],
                "xml_content_structure": None,
                "valid": False,
            }
        xml_content = response["response"].content
        try:
            equivalent_dict = xmltodict.parse(xml_content)
            xml_content_structure = self.get_dictionary_column_structure(dictionary_content=equivalent_dict)
            return {
                "error": None,
                "xml_content_structure": xml_content_structure,
                "valid": True,
            }
        except Exception as e:
            return {
                "error": f"Could not parse xml file, {str(e)}",
                "xml_content_structure": None,
                "valid": False,
            }
        
    def generate_metadata(self, file_url):
        """
        Wrapper function to wrap helper functions for metadata generation.

        Args:
            1. file_url(str): URL to the XML file for which metadata is to be generated.

        Returns:
            1. dict: The generated metadata.

        Raises:
            1. Exception: If the file is not valid XML or if the file is empty.
        """

        result_obj = self.get_xml_content_structure(xml_file_url=file_url)
        if not result_obj.get("valid"):
            raise Exception(result_obj.get("error"))
        xml_content_structure = result_obj.get("xml_content_structure")
        result = self.call_generator(method=config('GENERATOR_TYPE'), input_data={'xml':xml_content_structure})
        return result
        
class EXCELMetadataGenerator(MetaDataGeneratorBase):
    def fetch_excel_file(self, excel_file_url: str):
        """
        Fetches an Excel file from a given URL.

        Args:
            excel_file_url (str): The URL to the Excel file to be fetched.

        Returns:
            dict: A dictionary containing:
                - "error" (str): An error message if the fetching fails, None otherwise.
                - "fetched" (bool): A flag indicating whether the file was successfully fetched.
                - "response" (requests.Response or None): The HTTP response object if fetched successfully, None otherwise.
        """

        try:
            response = requests.get(excel_file_url)
            if response.status_code != 200:
                return {
                    "error": f"Could not fetch excel file, status code: {response.status_code}",
                    "fetched": False,
                    "response": None,
                }
            return {"error": None, "fetched": True, "response": response}
        except Exception as e:
            return {
                "error": f"Could not fetch excel file, {str(e)}",
                "fetched": False,
                "response": None,
            }
    
    def get_dataframe(self, excel_file_url):
        """
        Fetches an Excel file and returns a pandas DataFrame object.

        Args:
            excel_file_url (str): The URL to the Excel file to be fetched.

        Returns:
            dict: A dictionary containing:
                - "error" (str): An error message if the fetching or parsing fails, None otherwise.
                - "valid" (bool): A flag indicating whether the file was successfully fetched and parsed.
                - "dataframe" (pandas.DataFrame or None): The pandas DataFrame object if fetched and parsed successfully, None otherwise.
        """
        
        response_obj = self.fetch_excel_file(excel_file_url)
        if not response_obj["fetched"]:
            return {
                "error": response_obj["error"],
                "valid": False,
                "dataframe": None
            }
        excel_content = response_obj["response"].content
        excel_content = BytesIO(excel_content)
        try:
            dataframe = pd.read_excel(excel_content, sheet_name=0)
            return {"error": None, "valid": True, "dataframe": dataframe}
        except Exception as e:
            return {
                "error": f"Could not parse excel file, {str(e)}",
                "valid": False,
                "dataframe": None
            }

    def get_content_structure(self, dataframe):
        """
        Generates a list of dictionaries where each dictionary contains the column name and its corresponding Pandas data type
        for a given DataFrame.

        Args:
            dataframe (pandas.DataFrame): The DataFrame for which content structure is to be generated.

        Returns:
            list: A list of dictionaries, each containing the column name and its data type.
        """
        
        content_structure = []
        for column in dataframe.columns:
            structure_dict = {
                "column_name": column,
                "column_pandas_datatype": dataframe.dtypes[column],
            }
            content_structure.append(structure_dict)
        return content_structure

    def get_structure_for_all_sheets(self, dataframe_dict):
        """
        Generates the content structure for all sheets in a given dictionary of DataFrames.

        Args:
            dataframe_dict (dict): A dictionary where keys are sheet names and values are pandas DataFrames.

        Returns:
            list: A list of dictionaries, each containing the sheet name and its corresponding content structure,
                which is a list of dictionaries with column names and their data types.
        """

        total_content_structure = []
        for key, value in dataframe_dict.items():
            content_structure = self.get_content_structure(value)
            content_structure_dict = {
                "sheet_name": key,
                "content_structure": content_structure
            }
            total_content_structure.append(content_structure_dict)
        return total_content_structure

    def generate_metadata(self, file_url):
        """
        Wrapper function to wrap helper functions for metadata generation.

        Args:
            1. file_url(str): URL to the xlsx/xls file for which metadata is to be generated.

        Returns:
            1. dict: The generated metadata.

        Raises:
            1. Exception: If the file is not valid xlsx/xls or if the file is empty.
        """

        result_obj = self.get_dataframe(excel_file_url=file_url)
        if not result_obj.get("valid"):
            raise Exception(result_obj.get("error"))
        excel_dataframe = result_obj.get("dataframe")
        excel_content_structure = self.get_content_structure(dataframe=excel_dataframe)
        result = self.call_generator(method=config('GENERATOR_TYPE'), input_data={'excel':excel_content_structure})
        return result
