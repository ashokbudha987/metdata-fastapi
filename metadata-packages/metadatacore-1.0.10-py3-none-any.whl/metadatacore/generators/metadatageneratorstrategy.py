import re
from typing import Any, Dict, Optional
from langchain_core.prompts import ChatPromptTemplate
import yaml
from langchain_openai import ChatOpenAI
from abc import ABC, abstractmethod
from decouple import config


class MetadataGeneratorStrategy(ABC):
    """
    The MetadataGeneratorStrategy class is an abstract base class that defines the structure for different metadata generation strategies. It includes a method for generating metadata and initializes a dictionary to store the final metadata.

    Methods:
    generate(self, data: Dict[str, Any]) -> Dict[str, Any]:
    Abstract method that must be implemented by subclasses to generate metadata from the provided data.

    """

    def __init__(self):
        self._name = "Metadata Generator"
        self.final_metadata = {
            "subject_area": "",
            "source": [{"table": "", "joins": []}],
            "attributes": {},
            "metrics": {},
            "columns": {},
        }


class LLMMetadataGenerator(MetadataGeneratorStrategy):
    """
    Metadata generator based on LLM
    """

    OPENAI_API_KEY = config("OPENAI_API_KEY")
    model = config("OPENAI_MODEL")

    def __init__(self):
        super().__init__()
        if self.model in ["o1", "o1-mini", "o1-preview"]:
            self.llm = ChatOpenAI(api_key=self.OPENAI_API_KEY, model=self.model)
        else:
            self.llm = ChatOpenAI(
                api_key=self.OPENAI_API_KEY, model=self.model, temperature=0
            )

        self.supported_data_types = {
            "ddl": "DDL",
            "json": "JSON",
            "dsv": "Delimiter Separated Values",
            "yml": "YAML",
            "xml": "XML",
            "excel":"Excel",
        }

    def generate(self, input_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Function to receive input and generate metadata using LLM
        """

        # process the input ie. if ddl is passed, extract it, if json is passed, extract it and so on
        if not input_data:
            raise ValueError(
                "Input data cannot be None. Please provide a valid data source."
            )

        for key, value in input_data.items():
            if key in self.supported_data_types:
                data_type = self.supported_data_types[key]
                data = input_data.get(key)
                break
            else:
                raise ValueError(f"Data type {key} is not supported.")

        prompt = ChatPromptTemplate.from_messages(
            [
                (
                    "human",
                    "You are a helpful assistant that generates metadata for a given data source."
                    """Given the following Parsed {data_type}: {input}

                    Generate metadata in the following YAML format following:
                    '''
                    subject_area: [subject area name]
                    source:
                        table_info:
                            - table: [table name]
                            joins: []
                                - join: [dimension table if given through foreign key only]
                                on: [join condition based on foreign key only]
                    columns:
                    [column_name]:
                        table: [table name]
                        name: [coulmn display name]
                        type: [data type only]
                        column: [column name]
                        desc: [description]
                        primary_key: [true/false]
                    '''
                    Rules:
                    - Classify columns as attributes (non-numeric) or metrics (numeric).
                    - All keys of yaml must be in lower case.
                    - All functions must be in lower case.
                    - Provide the output in the specified VALID yml format.
                    - Set the best possible datatype for the attribute by analysing the attribute name. 

                    Output:
                    """,
                ),
            ]
        )
        chain = prompt | self.llm
        response = chain.invoke(
            {
                "data_type": data_type,
                "input": data,
            }
        )
        response = response.content

        # Extract YAML string using regex
        yaml_match = re.search(r"```yaml\s*([\s\S]*?)\s*```", response)
        if yaml_match:
            yaml_str = yaml_match.group(1)
            try:
                metadata = yaml.safe_load(yaml_str)
            except yaml.YAMLError as e:
                raise ValueError(f"YAML parsing error: {e}")
        else:
            return {}

        self.final_metadata["subject_area"] = metadata.get("subject_area")
        self.final_metadata["source"] = metadata.get("source")
        self.final_metadata["columns"] = metadata.get("columns")

        return self.final_metadata


class PythonicMetadataGenerator(MetadataGeneratorStrategy):
    """
    Metadata generator based on Python code, manual generation
    """

    def __init__(self):
        super().__init__()

    def generate(self, parsed_ddl: dict) -> str:
        try:
            table_name = parsed_ddl.get("table_name")
            if not table_name:
                raise ValueError("Table name does not exist in parsed DDL.")
        except ValueError as e:
            raise e

        # Adding the main table to the source
        main_table_entry = {
            "table": f"{parsed_ddl.get('table_name')}",
            "joins": [],  # Joins can be added here if available
        }
        self.final_metadata["source"].append(main_table_entry)
        self.final_metadata["subject_area"] = parsed_ddl.get("table_name")

        # Process columns
        attributes, metrics = self.process_columns(parsed_ddl)
        self.final_metadata["attributes"] = attributes
        self.final_metadata["metrics"] = metrics

        return self.final_metadata

    def process_columns(self, parsed_ddl: dict) -> tuple:
        attributes = {}
        metrics = {}
        for column in parsed_ddl.get("columns", []):
            col_name = column["name"]
            col_type = column["type"].lower()

            base_entry = {
                "table": f"{parsed_ddl.get('schema', 'default')}."
                + f"{parsed_ddl.get('table_name', 'unknown')}",
                "name": col_name.replace("_", " ").title(),
                "type": col_type,
                "column": col_name,
                "desc": col_name.replace("_", " ").title(),
            }

            if self.is_metric(col_type):
                metric_entry = base_entry.copy()
                metric_entry["function"] = "sum"
                metrics[col_name] = metric_entry
            else:
                attribute_entry = base_entry.copy()
                attribute_entry["primary_key"] = col_name in parsed_ddl.get(
                    "primary_key", []
                )
                attributes[col_name] = attribute_entry

        return attributes, metrics

    def is_metric(self, col_type: str) -> bool:
        """
        Determine if a column is a metric based on its SQL data type.
        """
        numeric_types = [
            "int",
            "integer",
            "smallint",
            "bigint",
            "tinyint",
            "decimal",
            "numeric",
            "float",
            "real",
            "double",
            "number",
            "money",
            "smallmoney",
        ]
        return any(numeric_type in col_type for numeric_type in numeric_types)
