__version__ = "1.0.10"
# Metadata
__author__ = ["Bibek Khanal", "Ashok Budha", " Diwakar Serala"]
__email__ = [
    "bibek.khanal@yco.com.np",
    "ashok.budha@yco.com.np",
    "diwakar.serala@yco.com.np",
]
__license__ = "GNU General Public License v2 (GPLv2)"

# Documentation
"""
Analyze your data using natural language
"""
