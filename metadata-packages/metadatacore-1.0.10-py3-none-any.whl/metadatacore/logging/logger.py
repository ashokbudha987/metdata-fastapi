import logging
import os
from logging.handlers import TimedRotatingFileHandler

from decouple import config


def create_logger(name="executionlog", level="INFO", file="logs/execution.log"):
    """
    Creates a logger with the specified name, level, and file.

    Args:
        name (str): The name of the logger. Defaults to "executionlog".
        level (str): The level of the logger. Defaults to "INFO".
        file (str): The file path for the logger. Defaults to "logs/execution.log".

    Returns:
        logging.Logger: The created logger object.
    """
    logger = logging.getLogger(name)

    # Avoid duplicate handlers
    if len(logger.handlers) > 0:
        return logger

    # Set the log level
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))

    # Ensure log directory exists
    log_dir = os.path.dirname(file)
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    if config("ENABLE_LOGGING", default=False, cast=bool):
        # Add console handler if not already added
        if not any(isinstance(h, logging.StreamHandler) for h in logger.handlers):
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(
                logging.Formatter(
                    "{levelname} {asctime} {module} {process:d} {thread:d} {message}",
                    style="{",
                )
            )
            logger.addHandler(console_handler)

        # Add file handler if file logging is enabled
        if not any(isinstance(h, TimedRotatingFileHandler) for h in logger.handlers):
            file_handler = TimedRotatingFileHandler(
                file, when="midnight", interval=1, backupCount=7
            )
            file_handler.setFormatter(
                logging.Formatter(
                    "{levelname} {asctime} {module} {process:d} {thread:d} {message}",
                    style="{",
                )
            )
            logger.addHandler(file_handler)

    else:
        # Add a null handler if logging is disabled
        logger.addHandler(logging.NullHandler())

    return logger
