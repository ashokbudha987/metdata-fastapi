from typing import Any, Dict

from .base_reader import BaseReader


class SemanticReader(BaseReader):
    """
    A class to read and process metadata from YAML files within a specified folder structure.

    Attributes:
        semantics_dir (str): The base folder containing the semantics files.
    """

    valid_labels = ["folder", "type", "source", "metrics", "attributes", "columns","hierarchies"]

    def __init__(self, semantic_dict: dict):
        """
        Initializes the SemanticReader class.

        Args:
            metadata_folder (str): The path to the folder containing the metadata files.
            semantics_dir (str): The path to the folder containing the semantics files.

        Returns:
            None
        """
        self.semantic_dict = semantic_dict
        if semantic_dict:
            self.validate_assets(self.semantic_dict, self.valid_labels)
            self._registry = self.semantic_dict.get("registry", {"registered yml": {}})
            self.semantics_data = self.read_all_semantics()
        else:
            self._registry = {}
            self.semantics_data = {}

    def read_all_semantics(self) -> Dict[str, Dict[str, Any]]:
        """
        Reads the semantics data for all assets of different types.

        Returns:
            A dictionary containing the semantics data for each asset. The keys are the asset names and the values are dictionaries representing the semantics data.

        Raises:
            FileNotFoundError: If the semantics file for an asset cannot be found.
        """
        data = {}
        asset_value = self._registry.get("registered yml", {})
        if not asset_value:
            return data
        for asset_name in asset_value:
            data[asset_name] = self.semantic_dict.get("assets", {}).get(asset_name, {})
        return data

    def read_all_functions(self) -> Dict[str, Dict[str, Any]]:
        """
        Reads and combines all metadata based on the registry into a single dictionary.

        Returns:
            Dict[str, Dict[str, Any]]: A dictionary containing all combined metadata.
        """
        if self.semantic_dict:
            if self.semantic_dict.get("assets", {}).get("function"):
                try:
                    functions = (
                        self.semantic_dict.get("assets")
                        .get("function")
                        .get("function", {})
                    )
                    return functions
                except FileNotFoundError:
                    raise (FileNotFoundError("Function file not found"))
                except Exception as e:
                    raise (e)
        else:
            return {}
