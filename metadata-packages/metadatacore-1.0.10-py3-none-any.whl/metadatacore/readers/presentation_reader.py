import os
from typing import Any, Dict

import yaml

from .base_reader import BaseReader


class PresentationReader(BaseReader):
    """
    A class to read and process metadata from YAML files within a specified folder structure.

    Attributes:
        metadata_folder (str): The base folder containing the metadata files.
        _registry (Dict[str, list]): A dictionary holding the registry of assets.
        data (Dict[str, Dict[str, Any]]): A nested dictionary containing all read metadata.
    """

    def __init__(self, personalization_dict: dict):
        """
        Initializes the MetadataReader with the specified metadata folder.

        Args:
            metadata_folder (str): The path to the folder containing the metadata files.
        """
        self.personalization_dict = personalization_dict
        if self.personalization_dict:
            self.all_preference = self.read_all_schema()
        else:
            self.all_preference = {}

    def read_all_schema(self) -> Dict[str, Dict[str, Any]]:
        """
        Reads and combines all metadata based on the registry into a single dictionary.

        Returns:
            Dict[str, Dict[str, Any]]: A dictionary containing all combined metadata.
        """
        assets = self.personalization_dict.get("assets", {})
        if assets:
            first_key = next(iter(assets.keys()))
            data = assets.get(first_key, {})
            return data
        return {}
