from abc import ABC
from typing import Any, Dict, List


class BaseReader(ABC):
    """
    A base class to read and process metadata from YAML files within a specified folder structure.
    """

    def read_registry(self, registry_object) -> Dict[str, Any]:
        """
        Read the semantics registry file.

        This function reads the contents of the 'registry.yml' file located in the 'semantics_folder' directory.
        It uses the '_read_yaml_file' method to read the file and returns the contents as a dictionary.

        Returns:
            Dict[str, Any]: The contents of the 'registry.yml' file as a dictionary.
        """
        if not "registered yml" in registry_object:
            raise KeyError(f"Key `registered yml` not found in registry object.")
        return registry_object

    def validate_assets(self, yml_object: Dict, valid_labels: List) -> bool:
        """
        Validate the assets in the base folder.

        Args:
            yaml_object (Dict): The base folder path.
                sample: {
                "registry": <registry.yml object>,
                "assets": {
                    "product": <product.yml object>,
                    "customer": <customer.yml object>,
                    "date": <date.yml object>,
                    "location": <location.yml object>,
                }}
            valid_labels (List): A list of valid asset labels.

        Raises:
            ValueError: If an invalid asset label is found in a file.
            FileNotFoundError: If a file is not found in the base folder.
        """
        registered_yml = self.read_registry(yml_object.get("registry", {})).get(
            "registered yml", {}
        )
        if not registered_yml:
            return
        for file in registered_yml:
            data = yml_object.get("assets", {}).get(file, {})
            if not data:
                raise FileNotFoundError(f"yml object {file} not valid.")
            if not isinstance(data, dict):
                raise ValueError(f"Invalid data in {file}.yml")
            for key in data.keys():
                if key not in valid_labels:
                    raise ValueError(
                        f"Invalid asset label `{key}` in file `{file}.yml`"
                    )
                else:
                    continue
