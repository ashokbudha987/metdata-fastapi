from typing import Any, Dict

from .base_reader import BaseReader


class SchemaReader(BaseReader):
    """
    A class to read and process metadata from YAML files within a specified folder structure.

    Attributes:
        metadata_folder (str): The base folder containing the metadata files.
        _registry (Dict[str, list]): A dictionary holding the registry of assets.
        data (Dict[str, Dict[str, Any]]): A nested dictionary containing all read metadata.
    """

    valid_labels = [
        "subject_area",
        "source",
        "columns",
        "functions",
        "table_info",
    ]

    def __init__(self, schema_dict: dict):
        """
        Initializes the MetadataReader with the specified metadata folder.

        Args:
            metadata_folder (str): The path to the folder containing the metadata files.
        """
        self.schema_dict = schema_dict
        if self.schema_dict:
            self.validate_assets(self.schema_dict, self.valid_labels)
            self._registry = self.schema_dict.get("registry", {"registered yml": {}})
            self.all_schema = self.read_all_schema()
            self.__validate_hierarchy()
        else:
            self._registry = {}
            self.all_schema = {}

    def __validate_hierarchy(self):
        extracted_hierarchy = []
        for _, asset_values in self.all_schema.items():
            for table in asset_values.get("table_info"):
                extracted_hierarchy.extend(table.get("grain", {}).keys())

    def _inject_source(self, asset_value: dict) -> dict:
        source = asset_value.get("table_info", {})
        for metric in asset_value.get("columns", {}):
            asset_value["columns"][metric]["table_source"] = source
        return asset_value

    def read_all_schema(self) -> Dict[str, Dict[str, Any]]:
        """
        Reads and combines all metadata based on the registry into a single dictionary.

        Returns:
            Dict[str, Dict[str, Any]]: A dictionary containing all combined metadata.
        """
        data = {}
        for _, asset_value in self._registry.items():
            for asset_name in asset_value:
                data[asset_name] = self._inject_source(
                    self.schema_dict.get("assets", {}).get(asset_name, {})
                )
        return data
