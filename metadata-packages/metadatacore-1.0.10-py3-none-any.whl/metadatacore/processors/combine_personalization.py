from typing import Dict, Any
from metadatacore.readers.presentation_reader import PresentationReader

class CombinePersonalization:
    def __init__(self, final_metrics: dict, final_attributes: dict, final_columns: dict, personalization_dict):
        self.final_metrics = final_metrics
        self.final_attributes = final_attributes
        self.final_columns = final_columns
        self.personalization_dict = personalization_dict
        self.personalization = PresentationReader(personalization_dict).all_preference

    def combine_personalizations(self):
        """
        Combine the personalization data with the semantics data. Replace semantics content with personalization content
        for common attribute and metric names. Append personalization content where names do not match.
        """
        try: 
            (
                personalization_metrics,
                personalization_attributes,
            ) = self._extract_metrics_and_attributes_from_personalization(self.personalization)

            combined_final_metrics = self.combine_personalization_metrics(
                personalization_metrics
            )
            combined_final_attributes= self.combine_personalization_attributes(
                personalization_attributes
            )
            return combined_final_metrics, combined_final_attributes

        except Exception as e:
            raise Exception(f"Could not combine personalizations with semantics: {e}") 

    def _extract_metrics_and_attributes_from_personalization(self, all_preferences):
        """
        Extract metrics from the personalization data.

        Returns:
            dict: A dictionary of metrics and their definitions.
        """
        try:
            pers_metric = {}
            pers_attr = {}
            for _, value in all_preferences.items():
                metrics = value.get("metrics", {})
                attributes = value.get("attributes", {})
                for name, value in metrics.items():
                    pers_metric[name] = value
                for name, value in attributes.items():
                    pers_attr[name] = value
            return pers_metric, pers_attr
        except Exception as e:
            raise Exception(
                f"Could not extract metrics and attributes from personalization:: {e}"
            )
    
    def combine_personalization_attributes(
        self, personalization_attributes: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Combine the personalization data with the semantics data. Replace semantics content with personalization content
        for common attribute names. Append personalization content where names do not match.
        """
        try:
            for key, value in personalization_attributes.items():
                if key in self.final_attributes:
                    for k, v in value.items():
                        if isinstance(v, dict):
                            if k in self.final_attributes[key] and isinstance(
                                self.final_attributes[key][k], dict
                            ):
                                self.final_attributes[key][k].update(v)
                            else:
                                self.final_attributes[key][k] = v
                        elif isinstance(v, list):
                            if k in self.final_attributes[key] and isinstance(
                                self.final_attributes[key][k], list
                            ):
                                self.final_attributes[key][k].extend(v)
                                self.final_attributes[key][k] = list(
                                    set(self.final_attributes[key][k])
                                )
                            else:
                                self.final_attributes[key][k] = v
                        else:
                            self.final_attributes[key][k] = v
                else:
                    self.final_attributes[key] = value
            return self.final_attributes
        except Exception as e:
            raise e(f"Could not combine personalization attributes:: {e}")
        
    def combine_personalization_metrics(
        self, personalization_metrics: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Combine the personalization data with the semantics data. Replace semantics content with personalization content
        for common attribute and metric names. Append personalization content where names do not match.
        """
        try:
            for key, value in personalization_metrics.items():
                if key in self.final_metrics:
                    for k, v in value.items():
                        if isinstance(v, dict):
                            if k in self.final_metrics[key] and isinstance(
                                self.final_metrics[key][k], dict
                            ):
                                self.final_metrics[key][k].update(v)
                            else:
                                self.final_metrics[key][k] = v
                        elif isinstance(v, list):
                            if k in self.final_metrics[key] and isinstance(
                                self.final_metrics[key][k], list
                            ):
                                self.final_metrics[key][k].extend(v)
                                self.final_metrics[key][k] = list(
                                    set(self.final_metrics[key][k])
                                )
                            else:
                                self.final_metrics[key][k] = v
                        else:
                            self.final_metrics[key][k] = v
                else:
                    self.final_metrics[key] = value
            return self.final_metrics
        except Exception as e:
            raise e(f"Could not combine personalization metrics:: {e}")


