import re
from typing import Any, Dict, List
from metadatacore.readers.schema_reader import SchemaReader
from metadatacore.readers.semantic_reader import SemanticReader


class MetadataProcessor:
    def __init__(
        self,
        schema_dict: dict = {},
        semantics_dict: dict = None,
    ):
        self.schema_dict = schema_dict
        self.semantic_dict = semantics_dict
        self.__format_data()
        self.schema = SchemaReader(self.schema_dict)
        self.semantics = SemanticReader(self.semantic_dict)
        self._validate_imports()
        self._validate_calculations()
        self.resolve_imports()

    def combine_layers(self):
        try:
            if not self.semantic_dict:
                schema_metrics = self.get_all_metrices(self.schema.all_schema)
                schema_attr = self.get_all_attributes(self.schema.all_schema)
                schema_columns = self.get_all_columns(self.schema.all_schema)
                return schema_metrics, schema_attr, schema_columns

            schema_semantics_metrics = self.get_all_metrices(
                self.semantics.semantics_data
            )
            schema_semantics_attr = self.get_all_attributes(
                self.semantics.semantics_data
            )
            schema_semantics_columns = self.get_all_columns(
                self.semantics.semantics_data
            )
            return schema_semantics_metrics, schema_semantics_attr, schema_semantics_columns
        except Exception as e:
            raise

    def _validate_imports(self):
        """
        Validate that the imports mentioned in the semantics files are present in the schema or semantics files.

        Raises:
            ValueError: If an import source is not found in the schema or semantics.
        """
        for _, semantics_content in self.semantics.semantics_data.items():
            sources = semantics_content.get("source", {})
            if not sources:
                continue

            for source_name, items in sources.items():
                source_type, source_file = source_name.split(".")
                if source_type == "schema":
                    source_content = self.schema.all_schema.get(source_file)
                elif source_type == "semantics":
                    source_content = self.semantics.semantics_data.get(source_file)
                else:
                    raise ValueError(
                        f"Unknown source type '{source_type}' in source '{source_name}'"
                    )

                if not source_content:
                    raise ValueError(
                        f"Source '{source_name}' not found in schema or semantics data"
                    )

                columns_to_validate = items.get("columns", [])
                attributes_to_validate = items.get("attributes", [])
                metrics_to_validate = items.get("metrics", [])

                # Validate attributes
                if "<all>" not in attributes_to_validate:
                    for attribute in attributes_to_validate:
                        if attribute not in source_content.get("attributes", {}):
                            raise ValueError(
                                f"Attribute '{attribute}' not found in '{source_name}'"
                            )

                # Validate metrics
                if "<all>" not in metrics_to_validate:
                    for metric in metrics_to_validate:
                        if metric not in source_content.get("metrics", {}):
                            raise ValueError(
                                f"Metric '{metric}' not found in '{source_name}'"
                            )

                # Validate columns
                if "<all>" not in columns_to_validate:
                    for column in columns_to_validate:
                        if column not in source_content.get("columns", {}):
                            raise ValueError(
                                f"Column '{column}' not found in '{source_name}'"
                            )

    def _validate_calculations(self):
        """
        Validate that metrics mentioned in the calculation fields are available and valid.

        Raises:
            ValueError: If a metric in the calculation is not found among imported or locally defined items,
                        or if the calculation involves a mix of columns and metrics/attributes.
        """
        # Gather all columns from the schema
        all_columns = {
            column_name
            for schema_content in self.schema.all_schema.values()
            for column_name in schema_content.get("columns", {})
        }

        for _, semantics_content in self.semantics.semantics_data.items():
            imports = semantics_content.get("source", {})

            imported_items = set()
            imported_columns = set()

            for import_source, import_content in imports.items():
                # Determine if the source is from schema or semantics
                if import_source.startswith("schema."):
                    source_content = self.schema.all_schema.get(
                        import_source.split(".")[-1], {}
                    )
                elif import_source.startswith("semantics."):
                    source_content = self.semantics.semantics_data.get(
                        import_source.split(".")[-1], {}
                    )
                else:
                    raise ValueError(f"Unknown import source '{import_source}'")

                # Handle attributes
                attributes = import_content.get("attributes", [])
                if "<all>" in attributes:
                    imported_items.update(source_content.get("attributes", {}).keys())
                else:
                    imported_items.update(attributes)

                # Handle metrics
                metrics = import_content.get("metrics", [])
                if "<all>" in metrics:
                    imported_items.update(source_content.get("metrics", {}).keys())
                else:
                    imported_items.update(metrics)

                # Handle columns
                columns = import_content.get("columns", [])
                if "<all>" in columns:
                    imported_columns.update(source_content.get("columns", {}).keys())
                else:
                    imported_columns.update(columns)

            # Get locally defined attributes, metrics, and columns
            local_attributes = set(semantics_content.get("attributes", {}).keys())
            local_metrics = set(semantics_content.get("metrics", {}).keys())
            local_columns = set(semantics_content.get("columns", {}).keys())

            all_valid_items = imported_items | local_attributes | local_metrics
            all_valid_columns = imported_columns | local_columns

            # Validate the calculations
            items = {
                **semantics_content.get("attributes", {}),
                **semantics_content.get("metrics", {}),
            }

            for item_name, item_content in items.items():
                calculation = item_content.get("calculation")
                if calculation:
                    metrics_in_calculation = self.extract_calculation(calculation)

                    # Track columns and non-column items in the calculation
                    column_count = 0
                    non_column_count = 0

                    for metric in metrics_in_calculation:
                        if (
                            metric not in all_valid_items
                            and metric not in all_valid_columns
                        ):
                            raise ValueError(
                                f"Item '{metric}' in calculation of '{item_name}' not found among imported or locally defined items"
                            )

                        if metric in all_valid_items:
                            non_column_count += 1
                        else:
                            column_count += 1

                    # If both columns and non-columns are used together, raise an error
                    if column_count > 0 and non_column_count > 0:
                        raise ValueError(
                            f"Calculation for '{item_name}' contains both columns and metrics/attributes. "
                            "This combination is invalid. Please ensure calculations use only columns or only metrics/attributes."
                        )

    @staticmethod
    def extract_calculation(calculation: str) -> list:
        """
        Extract metrics from the calculation field using regex to find anything within square brackets.

        Args:
            calculation (str): The calculation string.

        Returns:
            list: A list of metrics found in the calculation string.
        """
        return re.findall(r"\[([^\]]+)\]", calculation)

    def resolve_imports(self):
        """
        Resolve imports mentioned in the semantics files and fetch their definitions from the schema or semantics files.

        Updates the semantics data with the imported definitions.

        Raises:
            ValueError: If an import source or item is not found in the schema or semantics files.
        """
        for _, semantics_content in self.semantics.semantics_data.items():
            sources = semantics_content.get("source", {})
            if not sources:
                continue

            resolved_attributes = {}
            resolved_metrics = {}
            resolved_columns = {}

            for source_name, items in sources.items():
                source_type, source_file = source_name.split(".")
                if source_type == "schema":
                    source_content = self.schema.all_schema.get(source_file)
                elif source_type == "semantics":
                    source_content = self.semantics.semantics_data.get(source_file)
                else:
                    raise ValueError(
                        f"Unknown source type '{source_type}' in source '{source_name}'"
                    )

                if not source_content:
                    raise ValueError(
                        f"Source '{source_name}' not found in schema or semantics data"
                    )

                attributes_to_import = items.get("attributes", [])
                metrics_to_import = items.get("metrics", [])
                columns_to_import = items.get("columns", [])

                # Resolve attributes
                if "<all>" in attributes_to_import:
                    resolved_attributes = {
                        **resolved_attributes,
                        **source_content.get("attributes", {}),
                    }
                else:
                    for attribute in attributes_to_import:
                        attr_def = source_content.get("attributes", {}).get(attribute)
                        if not attr_def:
                            raise ValueError(
                                f"Attribute '{attribute}' not found in '{source_name}'"
                            )
                        resolved_attributes[attribute] = attr_def

                # Resolve metrics
                if "<all>" in metrics_to_import:
                    resolved_metrics = {
                        **resolved_metrics,
                        **source_content.get("metrics", {}),
                    }
                else:
                    for metric in metrics_to_import:
                        metric_def = source_content.get("metrics", {}).get(metric)
                        if not metric_def:
                            raise ValueError(
                                f"Metric '{metric}' not found in '{source_name}'"
                            )
                        resolved_metrics[metric] = metric_def

                # Resolve Columns
                if "<all>" in columns_to_import:
                    resolved_columns = {
                        **resolved_columns,
                        **source_content.get("columns", {}),
                    }
                else:
                    for column in columns_to_import:
                        column_def = source_content.get("columns", {}).get(column)
                        if not column_def:
                            raise ValueError(
                                f"Column '{column}' not found in '{source_name}'"
                            )
                        resolved_columns[column] = column_def

            # Update the semantics content with resolved attributes, metrics, and columns
            semantics_content["attributes"] = {
                **semantics_content.get("attributes", {}),
                **resolved_attributes,
            }
            semantics_content["metrics"] = {
                **semantics_content.get("metrics", {}),
                **resolved_metrics,
            }
            semantics_content["columns"] = {
                **semantics_content.get("columns", {}),
                **resolved_columns,
            }
            # Refined merging logic to ensure columns only merge into metrics or attributes, and are deleted from columns
            MetadataProcessor.merge_columns_to_attributes_or_metrics(
                semantics_content.get("columns", {}), semantics_content.get("attributes", {}), semantics_content.get("metrics", {})
            )


    @staticmethod
    def match_substring(sentence: str, substring: str) -> bool:
        """
        Check if a substring is present in a sentence.

        Args:
            sentence (str): The sentence to search in.
            substring (str): The substring to search for.

        Returns:
            bool: True if the substring is present in the sentence, False otherwise.
        """
        # Convert both the sentence and substring to lowercase for case-insensitive matching
        sentence = sentence.lower()
        substring = substring.lower()

        # Escape any special characters in the substring to ensure they are treated as literals
        pattern = r"\b" + re.escape(substring) + r"\b"

        # Use regular expressions to search for the substring in the sentence as a whole word
        return bool(re.search(pattern, sentence))

    def get_all_metrices(self, yml_obj: dict) -> dict:
        """
        Returns all the metrics in the metadata.
        """
        try:
            all_metrics = {}
            for subject_area in yml_obj.keys():
                for metric_key, metric_value in (
                    yml_obj.get(subject_area, {}).get("metrics", {}).items()
                ):
                    all_metrics[metric_key] = metric_value
            return all_metrics
        except Exception as e:
            raise e("Error fetching all metrices:: {e}")

    def get_all_attributes(self, yml_obj: dict) -> dict:
        """
        Returns all the attributes in the metadata.
        """
        try:
            all_attributes = {}
            for subject_area in yml_obj.keys():
                for attribute_key, attribute_value in (
                    yml_obj.get(subject_area, {}).get("attributes", {}).items()
                ):
                    all_attributes[attribute_key] = attribute_value
            return all_attributes
        except Exception as e:
            raise e("Error fetching all attributes:: {e}")

    def get_all_columns(self, yml_obj: dict) -> dict:
        """
        Returns all the columns in the metadata.
        """
        try:
            all_columns = {}
            for subject_area in yml_obj.keys():
                for column_key, column_value in (
                    yml_obj.get(subject_area, {}).get("columns", {}).items()
                ):
                    all_columns[column_key] = column_value
            return all_columns
        except Exception as e:
            raise e("Error fetching all columns:: {e}")

    def search_metrics(self, word: str) -> dict:
        """
        Searches for metrics in the metadata based on a given word.
        """
        for subject_area in self.semantics.semantics_data.keys():
            for metric in self.semantics.semantics_data[subject_area]["metrics"].keys():
                if self.match_substring(metric["name"], word):
                    return metric

    def _extract_metric_info_from_calculation(
        self,
        keywords: dict,
        final_metrics: dict,
        final_attributes: dict,
        final_columns: dict,
    ):
        try:
            calculation_metrics = {}
            calculation_attributes = {}
            calculation_columns = {}
            for _, value in keywords.items():
                calculations = self.extract_calculation(value.get("calculation", ""))
                for matched_keywords in calculations:
                    if final_metrics.get(matched_keywords):
                        calculation_metrics.update(
                            {matched_keywords: final_metrics.get(matched_keywords, {})}
                        )
                    if final_attributes.get(matched_keywords):
                        calculation_attributes.update(
                            {
                                matched_keywords: final_attributes.get(
                                    matched_keywords, {}
                                )
                            }
                        )
                    if final_columns.get(matched_keywords):
                        calculation_columns.update(
                            {matched_keywords: final_columns.get(matched_keywords, {})}
                        )
            return calculation_metrics, calculation_attributes, calculation_columns
        except Exception as e:
            raise e(f"Could not extract metric info from calculation:: {e}")

    def _extract_metric_info_from_includes(
        self,
        keywords: dict,
        final_metrics: dict,
        final_attributes: dict,
        final_columns: dict,
    ):
        include_metrics = {}
        include_attributes = {}
        include_columns = {}
        for _, value in keywords.items():
            includes = value.get("include", [])
            for matched_keywords in includes:
                if final_metrics.get(matched_keywords):
                    include_metrics.update(
                        {matched_keywords: final_metrics.get(matched_keywords, {})}
                    )
                if final_attributes.get(matched_keywords):
                    include_attributes.update(
                        {matched_keywords: final_attributes.get(matched_keywords, {})}
                    )
                if final_columns.get(matched_keywords):
                    include_columns.update(
                        {matched_keywords: final_columns.get(matched_keywords, {})}
                    )
        return include_metrics, include_attributes, include_columns

    def _extract_function(self, matched_keywords: dict):
        try:
            extracted_functions = {}
            functions = self.semantics.read_all_functions()
            if functions:
                for _, value in matched_keywords.items():
                    if value.get("function"):
                        if functions.get(value.get("function")):
                            extracted_functions.update(
                                {
                                    value.get("function"): functions.get(
                                        value.get("function")
                                    )
                                }
                            )
            return extracted_functions
        except Exception as e:
            raise e(f"Could not extract function:: {e}")

    def get_all_functions(self):
        return self.semantics.read_all_functions()

    @staticmethod
    def merge_columns_to_attributes_or_metrics(columns, attributes, metrics):
        columns_to_delete = []  # Keep track of columns to delete
        try:
            for col_key, col_value in columns.items():
                if col_key in attributes.keys() and col_key not in metrics.keys():
                    # Merge into attributes if it exists only in attributes
                    for k, v in col_value.items():
                        if isinstance(v, dict):
                            if k in attributes[col_key] and isinstance(attributes[col_key][k], dict):
                                attributes[col_key][k].update(v)
                            else:
                                attributes[col_key][k] = v
                        elif isinstance(v, list):
                            if k in attributes[col_key] and isinstance(attributes[col_key][k], list):
                                attributes[col_key][k].extend(v)
                                attributes[col_key][k] = list(set(attributes[col_key][k]))  # Remove duplicates
                            else:
                                attributes[col_key][k] = v
                        else:
                            attributes[col_key][k] = v
                    columns_to_delete.append(col_key)  # Mark column for deletion

                elif col_key in metrics.keys() and col_key not in attributes.keys():
                    for k, v in col_value.items():
                        if isinstance(v, dict):
                            if k in metrics[col_key] and isinstance(metrics[col_key][k], dict):
                                metrics[col_key][k].update(v)
                            else:
                                metrics[col_key][k] = v
                        elif isinstance(v, list):
                            if k in metrics[col_key] and isinstance(metrics[col_key][k], list):
                                metrics[col_key][k].extend(v)
                                metrics[col_key][k] = list(set(metrics[col_key][k]))  # Remove duplicates
                            else:
                                metrics[col_key][k] = v
                        else:
                            metrics[col_key][k] = v
                    columns_to_delete.append(col_key)  # Mark column for deletion

            # Delete merged columns from the columns section
            for col_key in columns_to_delete:
                del columns[col_key]
        except Exception as e:
            raise Exception(f"Could not merge columns into attributes/metrics: {e}")

    def __format_data(self) -> dict:
        if self.semantic_dict is None:
            return
        registry = self.semantic_dict.get("registry", {}).get("registered yml", [])
        if len(registry) == 0:
            self.semantic_dict = None 

    def get_hierarchies(self) -> dict:
        if not self.semantics:
            raise ValueError("Semantics data not found")

        all_hierarchies = {}
        drill_across_info = {}
        seen_hierarchies = set()

        for subject_area in self.semantics.semantics_data.keys():
            for hierarchy_key, hierarchy_value in (
                self.semantics.semantics_data.get(subject_area, {}).get("hierarchies", {}).items()
            ):
                if hierarchy_key in seen_hierarchies:
                    raise ValueError(f"Duplicate hierarchy {hierarchy_key} found")
                seen_hierarchies.add(hierarchy_key)

                parsed_levels = []
                hierarchy_drill_across = []  # Store drill-across info for this hierarchy

                for level in hierarchy_value:
                    if isinstance(level, dict):
                        level_name = level.get('level_name', None)
                        attributes = level.get('attributes', [])
                        drill_across = level.get('drill_across', [])
                        if drill_across:  # Extract drill-across details
                            for drill in drill_across:
                                hierarchy_drill_across.append({
                                    "source_hierarchy": hierarchy_key,
                                    "source_level_name": level_name,
                                    "target_hierarchy": drill.get('target_hierarchy'),
                                    "target_level_name": drill.get('target_level_name'),
                                })
                    else:
                        level_name = level
                        attributes = []

                    parsed_levels.append({
                        'level_name': level_name,
                        'attributes': attributes
                    })

                # Add levels to all_hierarchies
                all_hierarchies[hierarchy_key] = parsed_levels

                # Add drill-across info if present
                if hierarchy_drill_across:
                    drill_across_info[hierarchy_key] = hierarchy_drill_across
        return {"hierarchy_info":all_hierarchies, "drill_across_info":drill_across_info}
