import re
from typing import Any, Dict, List
from decouple import config

import yaml

from metadatacore.embedding.openai_embedding import OpenAIEmbedding

# EMBEDDING_MODEL = config('EMBEDDING_MODEL', default='open-ai')
EMBEDDING_MODEL = 'open-ai'

class NoAliasDumper(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True


class MetadataExtractor:
    """
    Extract relevant metadata from the user query given the final metrics, attributes, columns and functions.
    """

    def __init__(
            self, final_metrics, final_attributes, final_columns, all_functions=None
    ):
        self.final_metrics = final_metrics
        self.final_attributes = final_attributes
        self.final_columns = final_columns
        self.all_functions = all_functions
        if EMBEDDING_MODEL == 'open-ai':
            self.embedding = OpenAIEmbedding()
        # elif EMBEDDING_MODEL == 'sentence-transformer':
        #     self.embedding = SentenceTransformerEmbedding()

    @staticmethod
    def extract_metric(metric: str) -> list:
        """
        Extract metrics from the calculation field using regex to find anything within square brackets.

        Args:
            calculation (str): The calculation string.

        Returns:
            list: A list of metrics found in the calculation string.
        """
        return re.findall(r"\[([^\]]+)\]", metric)

    def _extract_metric_info_from_calculation(
            self,
            keywords: dict,
            final_metrics: dict,
            final_attributes: dict,
            final_columns: dict,
    ):  
        if not keywords or not isinstance(keywords, dict):
            return {}, {}, {}
        if not final_metrics or not isinstance(final_metrics, dict):
            final_metrics = {}
        if not final_attributes or not isinstance(final_attributes, dict):
            final_attributes = {}
        if not final_columns or not isinstance(final_columns, dict):
            final_columns = {}
        try:
            calculation_metrics = {}
            calculation_attributes = {}
            calculation_columns = {}
            for _, value in keywords.items():
                calculations = MetadataExtractor.extract_metric(
                    value.get("calculation", "")
                )
                for matched_keywords in calculations:
                    if final_metrics.get(matched_keywords):
                        calculation_metrics.update(
                            {matched_keywords: final_metrics.get(matched_keywords, {})}
                        )
                    if final_attributes.get(matched_keywords):
                        calculation_attributes.update(
                            {
                                matched_keywords: final_attributes.get(
                                    matched_keywords, {}
                                )
                            }
                        )
                    if final_columns.get(matched_keywords):
                        calculation_columns.update(
                            {matched_keywords: final_columns.get(matched_keywords, {})}
                        )
            return calculation_metrics, calculation_attributes, calculation_columns
        except Exception as e:
            raise e(f"Could not extract metric info from calculation:: {e}")

    def _extract_metric_info_from_filters(
            self,
            keywords: dict
    ):
        filters_metrics = {}
        filters_attributes = {}
        filters_columns = {}
        filter_conditions = {}
        matched_filters = []
        if not keywords or not isinstance(keywords, dict):
            return {}, {}, {}
        for _, value in keywords.items():
            filters = value.get("filters", []) + value.get("filter", [])
            if not isinstance(filters, list):
                continue
            for filter_line in filters:
                matched_filter = MetadataExtractor.extract_metric(filter_line)
                if len(matched_filter) > 0:
                    matched_filters.append(matched_filter[0])
            for matched_keywords in matched_filters:
                if self.final_metrics.get(matched_keywords):
                    filters_metrics.update(
                        {matched_keywords: self.final_metrics.get(matched_keywords, {})}
                    )
                if self.final_attributes.get(matched_keywords):
                    filters_attributes.update(
                        {
                            matched_keywords: self.final_attributes.get(
                                matched_keywords, {}
                            )
                        }
                    )
                if self.final_columns.get(matched_keywords):
                    filters_columns.update(
                        {matched_keywords: self.final_columns.get(matched_keywords, {})}
                    )
        return filters_metrics, filters_attributes, filters_columns

    @staticmethod
    def __isolate_source(data: dict) -> dict:
        if not data or not isinstance(data, dict):
            return [], {}
        try:
            source = []
            for key, value in data.items():
                if value.get("table_source", []):
                    source.extend(value.get("table_source", []))
                    data.get(key).pop("table_source")
            return source, data
        except Exception as e:
            raise e(f"Could not isolate source:: {e}")

    def _extract_metric_info_from_includes(self, keywords: dict):
        if not keywords or not isinstance(keywords, dict):
            return {}, {}, {}
        try:
            include_metrics = {}
            include_attributes = {}
            include_columns = {}
            for _, value in keywords.items():
                includes = value.get("include", [])
                if not isinstance(includes, list):
                    continue
                for matched_keywords in includes:
                    if self.final_metrics.get(matched_keywords):
                        include_metrics.update(
                            {
                                matched_keywords: self.final_metrics.get(
                                    matched_keywords, {}
                                )
                            }
                        )
                    if self.final_attributes.get(matched_keywords):
                        include_attributes.update(
                            {
                                matched_keywords: self.final_attributes.get(
                                    matched_keywords, {}
                                )
                            }
                        )
                    if self.final_columns.get(matched_keywords):
                        include_columns.update(
                            {
                                matched_keywords: self.final_columns.get(
                                    matched_keywords, {}
                                )
                            }
                        )
            return include_metrics, include_attributes, include_columns
        except Exception as e:
            raise e(
                f"Could not extract metric info from includes, include valid name in 'includes':: {e}"
            )

    @staticmethod
    def preprocess_data(data_dict):
        processed = {}

        if not data_dict or not isinstance(data_dict, dict):
            return processed
        
        for key, value in data_dict.items():
            synonyms = value.get("synonym", []) + value.get("synonyms", [])
            terms = [value.get("name", "#########").lower()] + [
                syn.lower() for syn in synonyms
            ]
            processed[key] = {"terms": terms, "data": value}
        return processed

    @staticmethod
    def match_terms(query, processed_data):
        if not processed_data or not isinstance(processed_data, dict):
            return {} 
        matched_terms = {}
        exact_matches = {}
        partial_matches = {}
        for key, value in processed_data.items():
            for term in value["terms"]:
                pattern = r"\b" + re.escape(term.lower()) + r"\b"
                if re.search(pattern, query):
                    if " " in term:  # If the term is a multi-word term
                        exact_matches[key] = value["data"]
                    else:
                        partial_matches[key] = value["data"]
        # Prioritize exact matches of multi-word terms over single-word terms
        matched_terms.update(exact_matches)
        matched_terms.update(partial_matches)
        return matched_terms

    def extract_metric_and_attribute_from_user_query(
            self, user_query, use_embeddings=False
    ):
        """
        Extracts the metric and attribute from the user query.

        Args:
            user_query (str): The user query.

        Returns:
            dict: A dictionary containing the metric and attribute.
        """
        # match metrics in user query

        # Preprocess the user query into a lowercased string for easy matching
        try:
            extracted_functions = None
            all_sources = None
            query = user_query.lower()
            if not use_embeddings:
                # Use manual approach for filtering metadata from user query
                (
                    matched_metrics,
                    matched_attributes,
                    matched_columns,
                ) = self.extract_from_user_query_manual(query)
            else:
                # Use vector embeddings approach for filtering metadata from user query
                (
                    matched_metrics,
                    matched_attributes,
                    matched_columns,_,
                ) = self.extract_from_user_query_embedding(query)
            if self.final_columns is not None:
                (
                    matched_metrics,
                    matched_attributes,
                    matched_columns,
                    extracted_functions,
                    all_sources,
                ) = self.fetch_imports_from_matched_metadata(
                    matched_metrics, matched_attributes, matched_columns
                )
            if any(
                [matched_metrics, matched_attributes, matched_columns, extracted_functions]):
                final_metadata = {
                    "sources": (
                        self.__combine_source_without_duplicate(all_sources)
                        if all_sources
                        else "No Source Found"
                    ),
                    "metrics": matched_metrics if matched_metrics else "No Metrics Matched",
                    "attributes": (
                        matched_attributes
                        if matched_attributes
                        else "No Attributes Matched"
                    ),
                    "columns": matched_columns if matched_columns else "No Columns Matched",
                    "functions": extracted_functions
                    if extracted_functions
                    else "No Functions Matched",
                    "TAGS INFORMATION": ["""
    (STRICTLY FOLLOW THE TAGS AND THEIR PROVIDED DEFINITION)
    - name: Defines the name of the metric (used as search parameter)
    - desc: description of the metric or the column or the attribute
    - synonym: list of alternate names for the metric or the column or the attribute (used as search paramater)
    - calculation: Defines the formula that is used to calculate the metric (Strictly follow this formula whenever possible)
    - include: The column names defined under 'include' tag should always be additionally included in the final table result along with other required columns. Strictly ensure that the column names are included in the final table
    - filters: These are the filters that should be strictly included in the SQL query
    - granularity: defines the granularity of the data related to the metric that the table contains
    """]
                }
                return yaml.dump(
                    final_metadata,
                    default_flow_style=False,
                    sort_keys=False,
                    Dumper=NoAliasDumper,
                )
            else:
                return "No metadata found"

        except Exception as e:
            raise

    @staticmethod
    def __combine_source_without_duplicate(data: List[Dict]) -> dict:
        source = []
        for item in data:
            if item not in source:
                source.append(item)
        return source

    def _extract_function(self, matched_keywords: dict, all_functions: dict):
        try:
            extracted_functions = {}
            functions = all_functions
            if functions:
                if not matched_keywords or not isinstance(matched_keywords, dict):
                    return {}
                if not all_functions or not isinstance(all_functions, dict):
                    all_functions = {}
                for _, value in matched_keywords.items():
                    if value.get("function"):
                        if functions.get(value.get("function")):
                            extracted_functions.update(
                                {
                                    value.get("function"): functions.get(
                                        value.get("function")
                                    )
                                }
                            )
            return extracted_functions
        except Exception as e:
            raise e(f"Could not extract function:: {e}")

    def extract_from_user_query_manual(self, query):
        """
        Extracts the metric and attribute from the user query.

        Args:
            user_query (str): The user query.

        Returns:
            dict: A dictionary containing the metric and attribute.
        """
        processed_metrics = MetadataExtractor.preprocess_data(self.final_metrics)
        processed_attributes = MetadataExtractor.preprocess_data(self.final_attributes)
        processed_columns = MetadataExtractor.preprocess_data(self.final_columns)

        # Extract metrics and attributes based on the user query
        matched_metrics = MetadataExtractor.match_terms(query, processed_metrics)
        matched_attributes = MetadataExtractor.match_terms(query, processed_attributes)
        matched_columns = MetadataExtractor.match_terms(query, processed_columns)
        return matched_metrics, matched_attributes, matched_columns

    def extract_from_user_query_embedding(self, user_query):
        """
        Extracts the metric and attribute from the user query using vector embeddings

        Args:
            user_query (str): The user query.
        Returns:
            dict: A dictionary containing the metric and attribute.
        """
        final_metadata = [
            self.final_metrics,
            self.final_attributes,
            self.final_columns,
            {},
        ]

        # self.embedding.final_metadata = final_metadata

        filtered_metadata = self.embedding.get_final_filtered_metadata(user_query, final_metadata=final_metadata)
        # matched_metrics, matched_attributes, matched_columns, _ = filtered_metadata
        return filtered_metadata

    def fetch_imports_from_matched_metadata(
            self, matched_metrics, matched_attributes, matched_columns
    ):
        """
        Fetches the imports from the matched metadata
        
        Args:
            matched_metrics (dict): The matched metrics.
            matched_attributes (dict): The matched attributes.
            matched_columns (dict): The matched columns.
        
        Returns:    
            dict: A dictionary containing the imports.
        """
        (
            calculation_metrics,
            calculation_attributes,
            calculation_columns,
        ) = self._extract_metric_info_from_calculation(
            {**matched_metrics, **matched_attributes, **matched_columns},
            self.final_metrics,
            self.final_attributes,
            self.final_columns,
        )
        matched_metrics.update(calculation_metrics)
        matched_attributes.update(calculation_attributes)
        matched_columns.update(calculation_columns)
        if matched_metrics or matched_attributes or matched_columns:
            (
                included_metrics,
                included_attributes,
                included_columns,
            ) = self._extract_metric_info_from_includes(
                {**matched_metrics, **matched_attributes, **matched_columns}
            )
            matched_metrics.update(included_metrics)
            matched_attributes.update(included_attributes)
            matched_columns.update(included_columns)
            # extract from filters
            (
                filters_metrics,
                filters_attributes,
                filters_columns,
            ) = self._extract_metric_info_from_filters(
                {**matched_metrics, **matched_attributes, **matched_columns}
            )
            matched_metrics.update(filters_metrics)
            matched_attributes.update(filters_attributes)
            matched_columns.update(filters_columns)

        # extract functions from matched metrics
        extracted_functions = self._extract_function(
            {**matched_metrics, **matched_attributes, **matched_columns},
            self.all_functions,
        )
        metrics_source, matched_metrics = MetadataExtractor.__isolate_source(
            matched_metrics
        )
        attr_source, matched_attributes = MetadataExtractor.__isolate_source(
            matched_attributes
        )
        colm_source, matched_columns = MetadataExtractor.__isolate_source(
            matched_columns
        )

        all_sources = metrics_source + attr_source + colm_source

        # checking for dublicate in matched_columns and (matched_metrics and matched_attributes) if found delete the one in matched_columns
        for key, _ in matched_columns.copy().items():
            if key in matched_metrics.keys() or key in matched_attributes.keys():
                matched_columns.pop(key, None)

        return (
            matched_metrics,
            matched_attributes,
            matched_columns,
            extracted_functions,
            all_sources,
        )
