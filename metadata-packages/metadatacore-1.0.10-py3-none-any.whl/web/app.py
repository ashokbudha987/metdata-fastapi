from typing import List, Literal

import yaml
from fastapi import FastAPI
from simple_ddl_parser import DDLParser

from generators.pythonic_metadata_generator import PythonicMetadataGenerator
from metadatacore.metadata_processor import MetadataProcessor
from web.serializer import (
    CSVResourceSerializer,
    ExtractMetadataSerializer,
    MetadataMergeSerializer,
)
from web.utils import project_return

app = FastAPI()


@app.get("/healthcheck")
def healthcheck():
    return project_return(message="Healthy", data=None, status=200)


@app.post("/generate-db-metadata")
def generate_db_metadata(
    database_ddls: List[str],
):
    ddls = "\n\n".join(database_ddls)
    generator = PythonicMetadataGenerator()

    parsed_ddls = DDLParser(ddls).run(output_mode="hql")
    results = [
        generator.generate(parsed_ddl=parsed_ddl)
        for parsed_ddl in parsed_ddls
        if parsed_ddl
    ]

    yaml_data = yaml.dump(results, sort_keys=False)

    return project_return(
        message="Metadata generated",
        data=yaml_data,
        status=200,
    )


@app.post("/generate-csv-metadata")
def generate_csv_metadata(csv: CSVResourceSerializer):
    return project_return(
        message="Metadata generated",
        data={"content": "Csv: Not Implemented"},
        status=200,
    )


@app.post("/merge-metadata")
def merge_metadata(metadata_payload: MetadataMergeSerializer):
    processor = MetadataProcessor(
        schema_dict=metadata_payload.schema,
        semantics_dict=metadata_payload.semantics,
        personalization_dict=metadata_payload.personalization,
    )
    metric, attribute, column = processor.combine_layers()

    metadata = {
        "metric": metric,
        "attribute": attribute,
        "column": column,
    }

    return project_return(
        message="Metadata generated",
        data=metadata,
        status=200,
    )


def return_names(data):
    names = []
    for key, value in data.items():
        names.append(key)
        names.extend(value.get("synonym", []))
    return names


@app.post("/return-list")
def generate_metadata_list(metadata_payload: MetadataMergeSerializer):
    final_list = []
    processor = MetadataProcessor(
        schema_dict=metadata_payload.schema,
        semantics_dict=metadata_payload.semantics,
        personalization_dict=metadata_payload.personalization,
    )
    metric, attribute, column = processor.combine_layers()
    final_list.extend(return_names(metric))
    final_list.extend(return_names(attribute))
    final_list.extend(return_names(column))

    metadata_names = {"metric_names": list(set(final_list))}

    return project_return(
        message="Metadata List Generated",
        data=metadata_names,
        status=200,
    )


@app.post("/extract-metadata")
def extract_metadata(metadata_payload: ExtractMetadataSerializer):
    processor = MetadataProcessor()
    metadata = processor.extract_metric_and_attribute_from_user_query(
        user_query=metadata_payload.user_query,
        final_metrics=metadata_payload.metric,
        final_attributes=metadata_payload.attribute,
        final_columns=metadata_payload.column,
    )

    return project_return(
        message="Metadata generated",
        data=metadata,
        status=200,
    )
