from fastapi.responses import JSONResponse


def project_return(message=None, data=None, error=None, status=None):
    return JSONResponse(
        content={
            "message": message,
            "data": data,
            "status": status,
            "error": error,
        },
        status_code=status if status else 200,
    )
