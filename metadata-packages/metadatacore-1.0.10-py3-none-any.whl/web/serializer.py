from typing import Any

from pydantic import BaseModel


class DatabaseResourceSerializer(BaseModel):
    name: str
    host: str
    port: int
    username: str
    password: str
    db_type: str
    schema: str = None
    warehouse: str = None
    role: str = None
    included_tables: list[str] = []


class CSVResourceSerializer(BaseModel):
    id: str
    file_url: str
    file_name: str


class MetadataMergeSerializer(BaseModel):
    schema: dict[str, Any] = None
    semantics: dict[str, Any] = None
    personalization: dict[str, Any] = None


class ExtractMetadataSerializer(BaseModel):
    user_query: str
    metric: dict = {}
    attribute: dict = {}
    column: dict = {}


schema = {
    "registry": {
        "registered yml": [
            "sales",
            "marketing",
        ]
    },
    "assets": {
        "sales": {
            "subject": "redhat",
            "type": "sales",
        },
        "marketing": {
            "subject": "blue",
            "type": "marketing",
        },
    },
}
